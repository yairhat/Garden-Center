"use client"

// ============================================================
// VIVERO GARDEN CENTER MARYSIA — SITIO WEB COMPLETO
// TODO EL SITIO EN UN SOLO ARCHIVO.
// Para editar información busca: === DATOS EDITABLES ===
// ============================================================

import { useState, useEffect } from "react"

// ============================================================
// === DATOS EDITABLES — CAMBIA SOLO ESTA SECCIÓN ===
// ============================================================

const NEGOCIO = {
  nombre: "Garden Center Marysia",
  telefono: "5959544223",
  telefonoDisplay: "595 954 4223",
  whatsapp: "5959544223",
  whatsappMensaje: "Hola, vi su página web y me gustaría obtener más información sobre sus plantas.",
  direccion: "Carr al Molino de Flores 8, Xocotlan, Texcoco, Estado de México",
  mapsEmbed: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3761.5!2d-98.88!3d19.51!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d1f3b1b1b1b1b1%3A0x0!2sVivero+Garden+Center+Marysia!5e0!3m2!1ses!2smx!4v1234567890",
}

const HORARIOS = [
  { dias: "Lunes – Viernes", horas: "8:00 am – 6:00 pm" },
  { dias: "Sábado",          horas: "8:00 am – 5:00 pm" },
  { dias: "Domingo",         horas: "9:00 am – 3:00 pm" },
]

const ESTADISTICAS = [
  { numero: "15+",  etiqueta: "Años de experiencia" },
  { numero: "500+", etiqueta: "Especies disponibles" },
  { numero: "1,000+", etiqueta: "Clientes satisfechos" },
  { numero: "100%", etiqueta: "Garantía de calidad" },
]

const PRODUCTOS = [
  { icono: "🌿", titulo: "Plantas Ornamentales",  tag: "Gran variedad",   desc: "Helechos, anturios, monsteras, suculentas y cientos de especies para decorar tu hogar o jardín con vida." },
  { icono: "🍋", titulo: "Árboles Frutales",       tag: "Alta demanda",   desc: "Limón, naranja, guayaba, durazno, manzano y más. Cosecha tus propios frutos en casa." },
  { icono: "🪴", titulo: "Macetas y Macetones",    tag: "Todos tamaños",  desc: "Barro, cerámica, plástico y fibra de vidrio. Todos los tamaños para cada tipo de planta." },
  { icono: "🌱", titulo: "Tierra y Sustratos",     tag: "Calidad premium",desc: "Tierra negra, peat moss, tezontle, perlita y mezclas especiales para cada planta." },
  { icono: "🌸", titulo: "Plantas de Temporada",   tag: "Temporada actual",desc: "Flores de temporada, bulbos y plantas de exterior. Renueva tu jardín cada estación." },
  { icono: "💡", titulo: "Asesoría Personalizada", tag: "Gratis",         desc: "Te orientamos sobre qué planta es ideal para tu espacio, luz disponible y cuidados." },
]

const PASOS = [
  { num: "01", titulo: "Nos contactas",             desc: "Escríbenos por WhatsApp o llámanos. Cuéntanos qué planta buscas o qué espacio quieres decorar." },
  { num: "02", titulo: "Te mandamos fotos",          desc: "Te enviamos fotos reales de lo que tenemos disponible o productos similares a lo que necesitas." },
  { num: "03", titulo: "Apartas o nos visitas",      desc: "Aparta tu planta con anticipación o visítanos directamente en Texcoco. Te esperamos con gusto." },
]

const GALERIA = [
  { src: "https://placehold.co/600x450?text=Plantas+ornamentales+coloridas+en+vivero+luz+natural+verde", alt: "Plantas ornamentales en el vivero" },
  { src: "https://placehold.co/600x450?text=Arboles+frutales+jovenes+en+macetas+grandes+exhibicion", alt: "Árboles frutales jóvenes" },
  { src: "https://placehold.co/600x450?text=Area+de+suculentas+y+cactus+ordenados+con+luz+calida", alt: "Área de suculentas y cactus" },
  { src: "https://placehold.co/600x450?text=Plantas+tropicales+exuberantes+hojas+grandes+verdes", alt: "Plantas tropicales" },
  { src: "https://placehold.co/600x450?text=Coleccion+macetas+barro+ceramica+diferentes+tamanos", alt: "Colección de macetas" },
  { src: "https://placehold.co/600x450?text=Entrada+vivero+plantas+flores+coloridas+bienvenida", alt: "Entrada del vivero" },
]

const RESENAS = [
  { nombre: "María González",   inicial: "M", tiempo: "hace 2 semanas", estrellas: 5, texto: "Excelente vivero, tienen una variedad increíble. Me ayudaron a elegir las plantas perfectas para mi jardín y me dieron tips de cuidado. ¡Muy recomendado!" },
  { nombre: "Roberto Hernández",inicial: "R", tiempo: "hace 1 mes",     estrellas: 5, texto: "Fui buscando un árbol de limón y me sorprendió la calidad. Las plantas se ven muy sanas y el precio es justo. El personal muy atento y con mucho conocimiento." },
  { nombre: "Ana Martínez",     inicial: "A", tiempo: "hace 3 semanas", estrellas: 4, texto: "Muy buen lugar para comprar plantas. Tienen de todo: suculentas, frutales, ornamentales. Los precios están accesibles y el servicio es muy amable." },
]

const PLANTAS_ESPECIALES = [
  "Bonsáis y árboles miniatura",
  "Plantas exóticas y tropicales",
  "Orquídeas especiales",
  "Plantas medicinales",
  "Bambú y gramíneas",
  "Plantas acuáticas",
]

// ============================================================
// COMPONENTE PRINCIPAL
// ============================================================

export default function ViveroMarysia() {
  const [menuAbierto, setMenuAbierto]     = useState(false)
  const [scrolled, setScrolled]           = useState(false)
  const [lightbox, setLightbox]           = useState<number | null>(null)
  const [prodActivo, setProdActivo]       = useState<number | null>(null)

  const wa = `https://wa.me/${NEGOCIO.whatsapp}?text=${encodeURIComponent(NEGOCIO.whatsappMensaje)}`

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 60)
    window.addEventListener("scroll", fn)
    return () => window.removeEventListener("scroll", fn)
  }, [])

  useEffect(() => {
    if (lightbox === null) return
    const fn = (e: KeyboardEvent) => {
      if (e.key === "Escape")      setLightbox(null)
      if (e.key === "ArrowRight")  setLightbox((lightbox + 1) % GALERIA.length)
      if (e.key === "ArrowLeft")   setLightbox((lightbox - 1 + GALERIA.length) % GALERIA.length)
    }
    window.addEventListener("keydown", fn)
    return () => window.removeEventListener("keydown", fn)
  }, [lightbox])

  const ir = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })
    setMenuAbierto(false)
  }

  // Colores del sistema (evita repetir strings)
  const C = {
    verde:       "#1a3320",
    verdeMedio:  "#2d5a3d",
    verdeClaro:  "#e8f0eb",
    dorado:      "#c9a84c",
    crema:       "#f9f7f2",
    blanco:      "#ffffff",
    texto:       "#1a2e1a",
    textoSuave:  "#4a6a4a",
    wa:          "#25d366",
  }

  return (
    <div style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", background: C.crema, color: C.texto, overflowX: "hidden" }}>

      {/* FUENTES Y ESTILOS GLOBALES */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Playfair+Display:wght@400;500;700&display=swap');
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body { overflow-x: hidden; }
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-track { background: #f0ede6; }
        ::-webkit-scrollbar-thumb { background: #2d5a3d; border-radius: 999px; }

        @keyframes waPulse {
          0%,100% { box-shadow: 0 0 0 0 rgba(37,211,102,0.5); }
          60%      { box-shadow: 0 0 0 16px rgba(37,211,102,0); }
        }
        .wa-btn { animation: waPulse 2.5s ease-in-out infinite; }
        .wa-btn:hover { transform: scale(1.12) !important; }

        @keyframes fadeUp {
          from { opacity:0; transform:translateY(20px); }
          to   { opacity:1; transform:translateY(0); }
        }

        .nav-link { position:relative; text-decoration:none; transition:color .2s; }
        .nav-link::after { content:''; position:absolute; bottom:-3px; left:0; width:0; height:2px; background:#c9a84c; transition:width .3s; }
        .nav-link:hover::after { width:100%; }

        .btn-gold {
          display:inline-flex; align-items:center; gap:8px;
          background:#c9a84c; color:#1a2e1a;
          padding:13px 26px; border-radius:50px;
          font-weight:700; font-size:15px; text-decoration:none; border:none; cursor:pointer;
          transition:background .25s, transform .2s, box-shadow .2s;
        }
        .btn-gold:hover { background:#b8943a; transform:translateY(-2px); box-shadow:0 8px 24px rgba(201,168,76,.35); }

        .btn-green {
          display:inline-flex; align-items:center; gap:8px;
          background:#2d5a3d; color:white;
          padding:13px 26px; border-radius:50px;
          font-weight:600; font-size:15px; text-decoration:none; border:none; cursor:pointer;
          transition:background .25s, transform .2s, box-shadow .2s;
        }
        .btn-green:hover { background:#1e3e2a; transform:translateY(-2px); box-shadow:0 8px 24px rgba(30,70,40,.3); }

        .btn-outline-w {
          display:inline-flex; align-items:center; gap:8px;
          background:transparent; color:white;
          padding:12px 26px; border-radius:50px;
          font-weight:600; font-size:15px; text-decoration:none;
          border:2px solid rgba(255,255,255,0.45); cursor:pointer;
          transition:all .25s;
        }
        .btn-outline-w:hover { background:rgba(255,255,255,.1); border-color:white; transform:translateY(-2px); }

        .prod-card { transition:transform .3s ease, box-shadow .3s ease; }
        .prod-card:hover { transform:translateY(-7px); }

        .gallery-wrap { overflow:hidden; border-radius:16px; cursor:pointer; }
        .gallery-img  { width:100%; height:100%; object-fit:cover; display:block; transition:transform .4s ease; }
        .gallery-wrap:hover .gallery-img { transform:scale(1.06); }

        .review-card { transition:transform .3s, box-shadow .3s; }
        .review-card:hover { transform:translateY(-5px); box-shadow:0 20px 48px rgba(0,0,0,.2) !important; }

        .step-card { transition:transform .3s, box-shadow .3s; }
        .step-card:hover { transform:translateY(-6px); box-shadow:0 20px 48px rgba(30,70,40,.16) !important; }

        @media (max-width:768px) {
          .desktop-nav { display:none !important; }
          .hamburger   { display:flex !important; }
          .grid-2      { grid-template-columns:1fr !important; }
          .grid-3      { grid-template-columns:1fr !important; }
          .connector   { display:none !important; }
          .hero-stats  { grid-template-columns:repeat(2,1fr) !important; }
        }
      `}</style>

      {/* ══════════════════════════════════════
          NAVBAR
      ══════════════════════════════════════ */}
      <nav style={{
        position:"fixed", top:0, left:0, right:0, zIndex:100,
        padding: scrolled ? "10px 0" : "18px 0",
        background: scrolled ? "rgba(18,40,20,0.6)" : "transparent",
        backdropFilter: scrolled ? "blur(22px) saturate(1.8)" : "none",
        WebkitBackdropFilter: scrolled ? "blur(22px) saturate(1.8)" : "none",
        borderBottom: scrolled ? "1px solid rgba(255,255,255,0.08)" : "none",
        boxShadow: scrolled ? "0 8px 32px rgba(0,0,0,0.2)" : "none",
        transition:"all .4s ease",
      }}>
        <div style={{ maxWidth:1200, margin:"0 auto", padding:"0 24px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>

          {/* Logo */}
          <button onClick={() => ir("inicio")} style={{ background:"none", border:"none", cursor:"pointer", display:"flex", alignItems:"center", gap:10 }}>
            <svg width="38" height="38" viewBox="0 0 40 40" fill="none">
              <path d="M20 3C20 3 34 8 34 20C34 30 27 37 20 37C13 37 6 30 6 20C6 8 20 3 20 3Z" fill="#c9a84c" fillOpacity="0.2"/>
              <path d="M20 6C20 6 32 11 32 20C32 28.5 26.5 35 20 35C13.5 35 8 28.5 8 20C8 11 20 6 20 6Z" fill="none" stroke="#c9a84c" strokeWidth="1.3"/>
              <line x1="20" y1="10" x2="20" y2="33" stroke="#c9a84c" strokeWidth="0.9" strokeDasharray="2 2" opacity="0.65"/>
              <line x1="20" y1="16" x2="13" y2="22" stroke="#c9a84c" strokeWidth="0.7" opacity="0.5"/>
              <line x1="20" y1="16" x2="27" y2="22" stroke="#c9a84c" strokeWidth="0.7" opacity="0.5"/>
              <line x1="20" y1="23" x2="14" y2="28" stroke="#c9a84c" strokeWidth="0.7" opacity="0.4"/>
              <line x1="20" y1="23" x2="26" y2="28" stroke="#c9a84c" strokeWidth="0.7" opacity="0.4"/>
            </svg>
            <div>
              <div style={{ fontFamily:"'Playfair Display',serif", color:"white", fontSize:14, fontWeight:700, lineHeight:1.1 }}>Garden Center</div>
              <div style={{ display:"flex", alignItems:"center", gap:5, marginTop:3 }}>
                <span style={{ color:"#c9a84c", fontSize:10, fontWeight:700, letterSpacing:"0.2em", textTransform:"uppercase" }}>Marysia</span>
                <span style={{ width:3, height:3, borderRadius:"50%", background:"rgba(201,168,76,.5)", display:"inline-block" }}/>
                <span style={{ color:"rgba(255,255,255,.3)", fontSize:9, letterSpacing:"0.1em", textTransform:"uppercase" }}>Vivero</span>
              </div>
            </div>
          </button>

          {/* Links desktop */}
          <div className="desktop-nav" style={{ display:"flex", gap:24, alignItems:"center" }}>
            {[["Inicio","inicio"],["Nosotros","nosotros"],["Productos","productos"],["Cómo trabajamos","como-trabajamos"],["Galería","galeria"],["Contacto","contacto"]].map(([l,id]) => (
              <button key={id} onClick={() => ir(id)} className="nav-link"
                style={{ background:"none", border:"none", cursor:"pointer", color:"rgba(255,255,255,.85)", fontSize:13, fontWeight:500 }}>{l}</button>
            ))}
            <a href={wa} target="_blank" rel="noopener noreferrer" className="btn-gold" style={{ padding:"9px 18px", fontSize:13 }}>WhatsApp</a>
          </div>

          {/* Hamburger */}
          <button className="hamburger" onClick={() => setMenuAbierto(!menuAbierto)}
            style={{ display:"none", background:"none", border:"none", cursor:"pointer", color:"white", padding:4, alignItems:"center" }}>
            <svg width="26" height="26" fill="none" stroke="currentColor" strokeWidth="2">
              {menuAbierto
                ? <><line x1="4" y1="4" x2="22" y2="22"/><line x1="22" y1="4" x2="4" y2="22"/></>
                : <><line x1="3" y1="7" x2="23" y2="7"/><line x1="3" y1="13" x2="23" y2="13"/><line x1="3" y1="19" x2="23" y2="19"/></>}
            </svg>
          </button>
        </div>

        {/* Menú mobile */}
        {menuAbierto && (
          <div style={{ background:"rgba(15,30,15,.97)", padding:"16px 24px 28px", backdropFilter:"blur(12px)" }}>
            {[["Inicio","inicio"],["Nosotros","nosotros"],["Productos","productos"],["Cómo trabajamos","como-trabajamos"],["Galería","galeria"],["Contacto","contacto"]].map(([l,id]) => (
              <button key={id} onClick={() => ir(id)}
                style={{ display:"block", background:"none", border:"none", cursor:"pointer", color:"rgba(255,255,255,.8)", fontSize:16, fontWeight:500, padding:"13px 0", width:"100%", textAlign:"left", borderBottom:"1px solid rgba(255,255,255,.07)" }}>{l}</button>
            ))}
            <a href={wa} target="_blank" rel="noopener noreferrer" className="btn-gold" style={{ marginTop:20, width:"100%", justifyContent:"center" }}>Escribir por WhatsApp</a>
          </div>
        )}
      </nav>

      {/* ══════════════════════════════════════
          HERO
      ══════════════════════════════════════ */}
      <section id="inicio" style={{ position:"relative", minHeight:"100vh", display:"flex", alignItems:"center" }}>
        <img src="https://placehold.co/1600x900?text=Vivero+Garden+Center+Marysia+plantas+exuberantes+luz+dorada+naturaleza" alt="Vivero Garden Center Marysia"
          style={{ position:"absolute", inset:0, width:"100%", height:"100%", objectFit:"cover" }}/>
        <div style={{ position:"absolute", inset:0, background:"linear-gradient(to bottom, rgba(12,28,15,.52) 0%, rgba(12,28,15,.72) 55%, rgba(12,28,15,.93) 100%)" }}/>

        <div style={{ position:"relative", zIndex:1, maxWidth:1200, margin:"0 auto", padding:"110px 24px 80px" }}>
          <div style={{ maxWidth:680 }}>
            <div style={{ display:"inline-flex", alignItems:"center", gap:8, background:"rgba(201,168,76,.15)", border:"1px solid rgba(201,168,76,.35)", borderRadius:50, padding:"6px 16px", marginBottom:24 }}>
              <span style={{ width:7, height:7, borderRadius:"50%", background:"#4ade80", display:"inline-block" }}/>
              <span style={{ color:"#c9a84c", fontSize:12, fontWeight:600, letterSpacing:"0.1em", textTransform:"uppercase" }}>Texcoco, Estado de México</span>
            </div>

            <h1 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(38px,6vw,70px)", fontWeight:700, color:"white", lineHeight:1.1, marginBottom:20 }}>
              Tu jardín <span style={{ color:"#c9a84c" }}>ideal</span><br/>empieza aquí
            </h1>
            <p style={{ fontSize:"clamp(16px,2vw,19px)", color:"rgba(255,255,255,.78)", lineHeight:1.75, marginBottom:36 }}>
              Plantas ornamentales, árboles frutales, macetas y sustratos de la mejor calidad. Más de 15 años siendo el vivero de confianza de Texcoco y toda la región.
            </p>

            <div style={{ display:"flex", gap:14, flexWrap:"wrap" }}>
              <a href={`tel:${NEGOCIO.telefono}`} className="btn-gold">
                <svg width="17" height="17" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.1 1.18 2 2 0 012.11 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 7.09a16 16 0 006 6l.45-.45a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
                Llamar ahora
              </a>
              <a href={wa} target="_blank" rel="noopener noreferrer" className="btn-outline-w">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.124.558 4.118 1.531 5.847L.057 23.882l6.198-1.624A11.937 11.937 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-4.999-1.368l-.359-.213-3.678.964.981-3.585-.233-.369A9.812 9.812 0 012.182 12C2.182 6.566 6.566 2.182 12 2.182S21.818 6.566 21.818 12 17.434 21.818 12 21.818z"/></svg>
                Enviar WhatsApp
              </a>
            </div>
          </div>

          {/* Stats */}
          <div className="hero-stats" style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:14, marginTop:60, maxWidth:600 }}>
            {ESTADISTICAS.map(s => (
              <div key={s.etiqueta} style={{ background:"rgba(255,255,255,.07)", border:"1px solid rgba(255,255,255,.11)", borderRadius:14, padding:"18px 12px", backdropFilter:"blur(8px)", textAlign:"center" }}>
                <div style={{ fontFamily:"'Playfair Display',serif", fontSize:28, fontWeight:700, color:"#c9a84c", lineHeight:1 }}>{s.numero}</div>
                <div style={{ color:"rgba(255,255,255,.6)", fontSize:11, marginTop:5, lineHeight:1.4 }}>{s.etiqueta}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll hint */}
        <div style={{ position:"absolute", bottom:28, left:"50%", transform:"translateX(-50%)", display:"flex", flexDirection:"column", alignItems:"center", gap:6 }}>
          <span style={{ color:"rgba(255,255,255,.35)", fontSize:10, letterSpacing:"0.1em", textTransform:"uppercase" }}>Scroll</span>
          <div style={{ width:1, height:36, background:"linear-gradient(to bottom,rgba(255,255,255,.35),transparent)" }}/>
        </div>
      </section>

      {/* ══════════════════════════════════════
          SOBRE NOSOTROS
      ══════════════════════════════════════ */}
      <section id="nosotros" style={{ padding:"88px 24px", background:C.crema }}>
        <div className="grid-2" style={{ maxWidth:1200, margin:"0 auto", display:"grid", gridTemplateColumns:"1fr 1fr", gap:60, alignItems:"center" }}>

          {/* Imagen */}
          <div style={{ position:"relative" }}>
            <img src="https://placehold.co/560x480?text=Interior+vivero+plantas+ordenadas+luz+verde+calida+natural" alt="Interior del vivero Garden Center Marysia"
              style={{ width:"100%", height:460, objectFit:"cover", borderRadius:24, display:"block" }}/>
            <div style={{ position:"absolute", bottom:24, right:-16, background:"white", borderRadius:14, padding:"14px 18px", boxShadow:"0 12px 40px rgba(0,0,0,.11)", display:"flex", alignItems:"center", gap:12 }}>
              <div style={{ width:42, height:42, borderRadius:"50%", background:C.verdeClaro, display:"flex", alignItems:"center", justifyContent:"center" }}>
                <svg width="20" height="20" fill="none" stroke={C.verdeMedio} strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              </div>
              <div>
                <div style={{ fontSize:20, fontWeight:700, color:C.texto, lineHeight:1 }}>+15 años</div>
                <div style={{ fontSize:12, color:C.textoSuave, marginTop:3 }}>de experiencia</div>
              </div>
            </div>
          </div>

          {/* Texto */}
          <div>
            <div style={{ display:"inline-flex", alignItems:"center", gap:7, background:C.verdeClaro, color:C.verdeMedio, padding:"5px 14px", borderRadius:50, fontSize:12, fontWeight:600, letterSpacing:"0.06em", textTransform:"uppercase", marginBottom:16 }}>Sobre nosotros</div>
            <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(26px,3.5vw,40px)", fontWeight:700, color:C.texto, lineHeight:1.2, marginBottom:16 }}>
              El vivero de confianza<br/><span style={{ color:C.verdeMedio }}>de Texcoco</span>
            </h2>
            <p style={{ fontSize:16, color:C.textoSuave, lineHeight:1.75, marginBottom:18 }}>
              En Garden Center Marysia llevamos más de 15 años cultivando la pasión por las plantas. Somos un vivero familiar con profundo conocimiento del clima y suelos de la región.
            </p>
            <p style={{ fontSize:16, color:C.textoSuave, lineHeight:1.75, marginBottom:32 }}>
              Nuestra prioridad es que cada cliente se vaya con la planta correcta y el conocimiento para cuidarla. No vendemos plantas, <strong style={{ color:C.texto }}>creamos jardines felices.</strong>
            </p>

            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
              {[
                { t:"Plantas sanas",    d:"Revisadas y cuidadas diariamente" },
                { t:"Precios justos",   d:"Sin intermediarios, directo del vivero" },
                { t:"Asesoría real",    d:"Te decimos la verdad sobre cada planta" },
                { t:"Gran variedad",    d:"+500 especies disponibles todo el año" },
              ].map(p => (
                <div key={p.t} style={{ display:"flex", gap:10, alignItems:"flex-start" }}>
                  <div style={{ width:32, height:32, borderRadius:"50%", background:C.verdeClaro, flexShrink:0, display:"flex", alignItems:"center", justifyContent:"center" }}>
                    <svg width="14" height="14" fill="none" stroke={C.verdeMedio} strokeWidth="2.5" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
                  </div>
                  <div>
                    <div style={{ fontWeight:600, fontSize:13, color:C.texto }}>{p.t}</div>
                    <div style={{ fontSize:12, color:C.textoSuave, marginTop:2 }}>{p.d}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          PRODUCTOS
      ══════════════════════════════════════ */}
      <section id="productos" style={{ padding:"88px 24px", background:C.verde }}>
        <div style={{ maxWidth:1200, margin:"0 auto" }}>
          <div style={{ textAlign:"center", marginBottom:52 }}>
            <div style={{ display:"inline-flex", alignItems:"center", gap:7, background:"rgba(255,255,255,.07)", color:"#c9a84c", padding:"5px 14px", borderRadius:50, fontSize:12, fontWeight:600, letterSpacing:"0.06em", textTransform:"uppercase", marginBottom:14 }}>Lo que ofrecemos</div>
            <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(26px,3.5vw,40px)", fontWeight:700, color:"white", lineHeight:1.2, marginBottom:12 }}>
              Nuestros <span style={{ color:"#c9a84c" }}>productos</span>
            </h2>
            <p style={{ fontSize:16, color:"rgba(255,255,255,.6)", maxWidth:520, margin:"0 auto" }}>Todo lo que tu jardín necesita en un solo lugar.</p>
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(300px,1fr))", gap:22 }}>
            {PRODUCTOS.map((p, i) => (
              <div key={p.titulo} className="prod-card"
                onMouseEnter={() => setProdActivo(i)} onMouseLeave={() => setProdActivo(null)}
                style={{
                  background: prodActivo === i ? "rgba(255,255,255,.1)" : "rgba(255,255,255,.05)",
                  border: `1px solid ${prodActivo === i ? "rgba(201,168,76,.4)" : "rgba(255,255,255,.07)"}`,
                  borderRadius:20, padding:28,
                  boxShadow: prodActivo === i ? "0 20px 48px rgba(0,0,0,.25)" : "none",
                  transition:"all .3s ease",
                }}>
                <div style={{ fontSize:38, marginBottom:16 }}>{p.icono}</div>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
                  <h3 style={{ color:"white", fontSize:17, fontWeight:700 }}>{p.titulo}</h3>
                  <span style={{ background:"rgba(201,168,76,.15)", color:"#c9a84c", fontSize:10, fontWeight:600, padding:"3px 10px", borderRadius:50, whiteSpace:"nowrap", marginLeft:8 }}>{p.tag}</span>
                </div>
                <p style={{ color:"rgba(255,255,255,.58)", fontSize:14, lineHeight:1.7, marginBottom:18 }}>{p.desc}</p>
                <a href={wa} target="_blank" rel="noopener noreferrer"
                  style={{ display:"inline-flex", alignItems:"center", gap:5, color:"#c9a84c", fontSize:13, fontWeight:600, textDecoration:"none" }}>
                  Consultar disponibilidad
                  <svg width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          CÓMO TRABAJAMOS
      ══════════════════════════════════════ */}
      <section id="como-trabajamos" style={{ padding:"88px 24px", background:C.crema }}>
        <div style={{ maxWidth:1200, margin:"0 auto" }}>
          <div style={{ textAlign:"center", marginBottom:60 }}>
            <div style={{ display:"inline-flex", alignItems:"center", gap:7, background:C.verdeClaro, color:C.verdeMedio, padding:"5px 14px", borderRadius:50, fontSize:12, fontWeight:600, letterSpacing:"0.06em", textTransform:"uppercase", marginBottom:14 }}>Proceso fácil</div>
            <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(26px,3.5vw,40px)", fontWeight:700, color:C.texto, lineHeight:1.2, marginBottom:12 }}>
              ¿Cómo <span style={{ color:C.verdeMedio }}>trabajamos?</span>
            </h2>
            <p style={{ fontSize:16, color:C.textoSuave, maxWidth:500, margin:"0 auto" }}>Sin complicaciones. Desde que nos contactas hasta que tienes tu planta, todo es sencillo.</p>
          </div>

          <div className="grid-3" style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:28, position:"relative" }}>
            {PASOS.map((paso, i) => (
              <div key={paso.titulo} style={{ position:"relative" }}>
                {/* Conector */}
                {i < PASOS.length - 1 && (
                  <div className="connector" style={{ position:"absolute", top:42, left:"calc(100% - 14px)", width:28, height:2, background:"linear-gradient(to right,#2d5a3d,#c9a84c)", zIndex:0 }}/>
                )}
                <div className="step-card" style={{ background:"white", borderRadius:22, padding:30, boxShadow:"0 4px 24px rgba(30,70,40,.07)", position:"relative", zIndex:1, height:"100%" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:20 }}>
                    <div style={{ width:50, height:50, borderRadius:"50%", background:C.verdeClaro, display:"flex", alignItems:"center", justifyContent:"center" }}>
                      {i === 0 && <svg width="22" height="22" fill="none" stroke={C.verdeMedio} strokeWidth="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.1 1.18 2 2 0 012.11 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 7.09a16 16 0 006 6l.45-.45a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>}
                      {i === 1 && <svg width="22" height="22" fill="none" stroke={C.verdeMedio} strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>}
                      {i === 2 && <svg width="22" height="22" fill="none" stroke={C.verdeMedio} strokeWidth="2" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>}
                    </div>
                    <span style={{ fontFamily:"'Playfair Display',serif", fontSize:44, fontWeight:700, color:"#c9a84c", opacity:.35, lineHeight:1 }}>{paso.num}</span>
                  </div>
                  <h3 style={{ fontSize:18, fontWeight:700, color:C.texto, marginBottom:10 }}>{paso.titulo}</h3>
                  <p style={{ fontSize:14, color:C.textoSuave, lineHeight:1.7 }}>{paso.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div style={{ textAlign:"center", marginTop:48, background:"white", borderRadius:18, padding:"28px 24px", boxShadow:"0 4px 20px rgba(30,70,40,.06)" }}>
            <p style={{ fontSize:17, fontWeight:600, color:C.texto, marginBottom:18 }}>¿Listo para empezar? Escríbenos ahora mismo.</p>
            <a href={wa} target="_blank" rel="noopener noreferrer" className="btn-green">
              <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.124.558 4.118 1.531 5.847L.057 23.882l6.198-1.624A11.937 11.937 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-4.999-1.368l-.359-.213-3.678.964.981-3.585-.233-.369A9.812 9.812 0 012.182 12C2.182 6.566 6.566 2.182 12 2.182S21.818 6.566 21.818 12 17.434 21.818 12 21.818z"/></svg>
              Iniciar conversación en WhatsApp
            </a>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          PLANTAS ESPECIALES
      ══════════════════════════════════════ */}
      <section id="plantas-especiales" style={{ padding:"88px 24px", background:C.verdeMedio, position:"relative", overflow:"hidden" }}>
        <div style={{ position:"absolute", top:-80, right:-80, width:320, height:320, borderRadius:"50%", background:"rgba(255,255,255,.03)", pointerEvents:"none" }}/>
        <div style={{ position:"absolute", bottom:-60, left:-60, width:240, height:240, borderRadius:"50%", background:"rgba(201,168,76,.06)", pointerEvents:"none" }}/>

        <div className="grid-2" style={{ maxWidth:1200, margin:"0 auto", display:"grid", gridTemplateColumns:"1fr 1fr", gap:60, alignItems:"center", position:"relative", zIndex:1 }}>
          {/* Texto */}
          <div>
            <div style={{ display:"inline-flex", alignItems:"center", gap:7, background:"rgba(201,168,76,.15)", color:"#c9a84c", padding:"5px 14px", borderRadius:50, fontSize:12, fontWeight:600, letterSpacing:"0.06em", textTransform:"uppercase", marginBottom:16 }}>Servicio especial</div>
            <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(26px,3.5vw,40px)", fontWeight:700, color:"white", lineHeight:1.2, marginBottom:16 }}>
              Si no la tenemos,<br/><span style={{ color:"#c9a84c" }}>la conseguimos.</span>
            </h2>
            <p style={{ fontSize:16, color:"rgba(255,255,255,.72)", lineHeight:1.75, marginBottom:24 }}>
              ¿Buscas una planta especial que no encuentras en ningún lado? Nosotros la localizamos por ti. Tenemos una red de proveedores y productores especializados en todo el país.
            </p>
            <p style={{ fontSize:16, color:"rgba(255,255,255,.72)", lineHeight:1.75, marginBottom:32 }}>
              Solo cuéntanos qué buscas y en cuánto tiempo la necesitas, nosotros hacemos el resto.
            </p>
            {["Cuéntanos qué planta buscas","La localizamos con nuestros proveedores","Te avisamos disponibilidad y precio"].map((t, i) => (
              <div key={t} style={{ display:"flex", gap:12, alignItems:"center", marginBottom:14 }}>
                <div style={{ width:30, height:30, borderRadius:"50%", background:"rgba(201,168,76,.18)", border:"1px solid rgba(201,168,76,.38)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                  <span style={{ color:"#c9a84c", fontSize:12, fontWeight:700 }}>{i+1}</span>
                </div>
                <span style={{ color:"rgba(255,255,255,.85)", fontSize:15 }}>{t}</span>
              </div>
            ))}
            <div style={{ marginTop:28 }}>
              <a href={wa} target="_blank" rel="noopener noreferrer" className="btn-gold">
                Pedir planta especial
                <svg width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
              </a>
            </div>
          </div>

          {/* Tarjeta de ejemplos */}
          <div>
            <div style={{ background:"rgba(255,255,255,.07)", border:"1px solid rgba(255,255,255,.1)", borderRadius:22, padding:28, marginBottom:18 }}>
              <h3 style={{ color:"white", fontSize:16, fontWeight:700, marginBottom:18 }}>Plantas que podemos conseguirte:</h3>
              {PLANTAS_ESPECIALES.map(p => (
                <div key={p} style={{ display:"flex", alignItems:"center", gap:12, padding:"9px 12px", background:"rgba(255,255,255,.04)", borderRadius:10, marginBottom:8 }}>
                  <svg width="15" height="15" fill="none" stroke="#c9a84c" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                  <span style={{ color:"rgba(255,255,255,.78)", fontSize:14 }}>{p}</span>
                </div>
              ))}
            </div>
            {/* Promesa */}
            <div style={{ background:"rgba(201,168,76,.1)", border:"1px solid rgba(201,168,76,.28)", borderRadius:14, padding:"18px 22px", display:"flex", gap:14, alignItems:"flex-start" }}>
              <div style={{ width:36, height:36, borderRadius:"50%", background:"rgba(201,168,76,.18)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                <svg width="18" height="18" fill="none" stroke="#c9a84c" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
              </div>
              <div>
                <div style={{ color:"#c9a84c", fontWeight:700, fontSize:13, marginBottom:4 }}>Nuestra promesa</div>
                <div style={{ color:"rgba(255,255,255,.65)", fontSize:13, lineHeight:1.6 }}>Si no podemos conseguirla, te lo decimos con honestidad y buscamos la mejor alternativa para ti.</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          GALERÍA
      ══════════════════════════════════════ */}
      <section id="galeria" style={{ padding:"88px 24px", background:C.crema }}>
        <div style={{ maxWidth:1200, margin:"0 auto" }}>
          <div style={{ textAlign:"center", marginBottom:52 }}>
            <div style={{ display:"inline-flex", alignItems:"center", gap:7, background:C.verdeClaro, color:C.verdeMedio, padding:"5px 14px", borderRadius:50, fontSize:12, fontWeight:600, letterSpacing:"0.06em", textTransform:"uppercase", marginBottom:14 }}>Nuestro vivero</div>
            <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(26px,3.5vw,40px)", fontWeight:700, color:C.texto, lineHeight:1.2, marginBottom:12 }}>
              Una mirada a <span style={{ color:C.verdeMedio }}>nuestro espacio</span>
            </h2>
            <p style={{ fontSize:16, color:C.textoSuave, maxWidth:480, margin:"0 auto" }}>Ven a visitarnos o míranos desde aquí.</p>
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(280px,1fr))", gap:16 }}>
            {GALERIA.map((img, i) => (
              <div key={i} className="gallery-wrap" onClick={() => setLightbox(i)} style={{ aspectRatio:"4/3", position:"relative" }}>
                <img src={img.src} alt={img.alt} className="gallery-img"/>
              </div>
            ))}
          </div>

          <div style={{ textAlign:"center", marginTop:36 }}>
            <a href={wa} target="_blank" rel="noopener noreferrer" className="btn-green">Ver más fotos por WhatsApp</a>
          </div>
        </div>

        {/* Lightbox */}
        {lightbox !== null && (
          <div onClick={() => setLightbox(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.92)", zIndex:200, display:"flex", alignItems:"center", justifyContent:"center", padding:24 }}>
            <button onClick={e => { e.stopPropagation(); setLightbox((lightbox-1+GALERIA.length)%GALERIA.length) }}
              style={{ position:"absolute", left:16, top:"50%", transform:"translateY(-50%)", background:"rgba(255,255,255,.1)", border:"1px solid rgba(255,255,255,.2)", borderRadius:"50%", width:46, height:46, color:"white", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
              <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg>
            </button>
            <img src={GALERIA[lightbox].src} alt={GALERIA[lightbox].alt} onClick={e => e.stopPropagation()}
              style={{ maxWidth:"88vw", maxHeight:"82vh", borderRadius:14, objectFit:"contain" }}/>
            <button onClick={e => { e.stopPropagation(); setLightbox((lightbox+1)%GALERIA.length) }}
              style={{ position:"absolute", right:16, top:"50%", transform:"translateY(-50%)", background:"rgba(255,255,255,.1)", border:"1px solid rgba(255,255,255,.2)", borderRadius:"50%", width:46, height:46, color:"white", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
              <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
            </button>
            <button onClick={() => setLightbox(null)} style={{ position:"absolute", top:16, right:16, background:"rgba(255,255,255,.1)", border:"none", borderRadius:"50%", width:38, height:38, color:"white", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>
              <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
            <div style={{ position:"absolute", bottom:16, left:"50%", transform:"translateX(-50%)", color:"rgba(255,255,255,.45)", fontSize:12 }}>{lightbox+1} / {GALERIA.length}</div>
          </div>
        )}
      </section>

      {/* ══════════════════════════════════════
          RESEÑAS
      ══════════════════════════════════════ */}
      <section style={{ padding:"88px 24px", background:C.verde }}>
        <div style={{ maxWidth:1200, margin:"0 auto" }}>
          <div style={{ textAlign:"center", marginBottom:52 }}>
            <div style={{ display:"inline-flex", alignItems:"center", gap:7, background:"rgba(255,255,255,.07)", color:"#c9a84c", padding:"5px 14px", borderRadius:50, fontSize:12, fontWeight:600, letterSpacing:"0.06em", textTransform:"uppercase", marginBottom:14 }}>Lo que dicen</div>
            <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(26px,3.5vw,40px)", fontWeight:700, color:"white", lineHeight:1.2, marginBottom:12 }}>
              Opiniones <span style={{ color:"#c9a84c" }}>reales</span>
            </h2>
            <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:8, marginTop:8 }}>
              {[1,2,3,4].map(s => <svg key={s} width="18" height="18" viewBox="0 0 24 24" fill="#f59e0b"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>)}
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" strokeWidth="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              <span style={{ color:"rgba(255,255,255,.55)", fontSize:13 }}>4.5 / 5 en Google</span>
            </div>
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(300px,1fr))", gap:22 }}>
            {RESENAS.map(r => (
              <div key={r.nombre} className="review-card" style={{ background:"rgba(255,255,255,.05)", border:"1px solid rgba(255,255,255,.07)", borderRadius:20, padding:26, boxShadow:"none" }}>
                <div style={{ display:"flex", gap:3, marginBottom:14 }}>
                  {Array.from({ length:r.estrellas }).map((_,i) => <svg key={i} width="15" height="15" viewBox="0 0 24 24" fill="#f59e0b"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>)}
                </div>
                <p style={{ color:"rgba(255,255,255,.75)", fontSize:14, lineHeight:1.75, marginBottom:20, fontStyle:"italic" }}>&ldquo;{r.texto}&rdquo;</p>
                <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                  <div style={{ width:38, height:38, borderRadius:"50%", background:C.verdeMedio, display:"flex", alignItems:"center", justifyContent:"center" }}>
                    <span style={{ color:"#c9a84c", fontWeight:700, fontSize:15 }}>{r.inicial}</span>
                  </div>
                  <div>
                    <div style={{ color:"white", fontWeight:600, fontSize:13 }}>{r.nombre}</div>
                    <div style={{ color:"rgba(255,255,255,.38)", fontSize:11 }}>{r.tiempo}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          CONTACTO
      ══════════════════════════════════════ */}
      <section id="contacto" style={{ padding:"88px 24px", background:C.crema }}>
        <div style={{ maxWidth:1200, margin:"0 auto" }}>
          <div style={{ textAlign:"center", marginBottom:52 }}>
            <div style={{ display:"inline-flex", alignItems:"center", gap:7, background:C.verdeClaro, color:C.verdeMedio, padding:"5px 14px", borderRadius:50, fontSize:12, fontWeight:600, letterSpacing:"0.06em", textTransform:"uppercase", marginBottom:14 }}>Encuéntranos</div>
            <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(26px,3.5vw,40px)", fontWeight:700, color:C.texto, lineHeight:1.2, marginBottom:12 }}>
              ¿Cómo <span style={{ color:C.verdeMedio }}>llegar?</span>
            </h2>
          </div>

          <div className="grid-2" style={{ display:"grid", gridTemplateColumns:"1fr 1.4fr", gap:36, alignItems:"start" }}>
            {/* Info cards */}
            <div style={{ display:"flex", flexDirection:"column", gap:18 }}>
              {/* Dirección */}
              <div style={{ background:"white", borderRadius:16, padding:22, boxShadow:"0 2px 16px rgba(30,70,40,.06)", display:"flex", gap:14 }}>
                <div style={{ width:44, height:44, borderRadius:"50%", background:C.verdeClaro, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                  <svg width="20" height="20" fill="none" stroke={C.verdeMedio} strokeWidth="2" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                </div>
                <div>
                  <div style={{ fontWeight:700, fontSize:13, color:C.texto, marginBottom:4 }}>Dirección</div>
                  <div style={{ color:C.textoSuave, fontSize:14, lineHeight:1.55 }}>{NEGOCIO.direccion}</div>
                </div>
              </div>
              {/* Teléfono */}
              <div style={{ background:"white", borderRadius:16, padding:22, boxShadow:"0 2px 16px rgba(30,70,40,.06)", display:"flex", gap:14 }}>
                <div style={{ width:44, height:44, borderRadius:"50%", background:C.verdeClaro, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                  <svg width="20" height="20" fill="none" stroke={C.verdeMedio} strokeWidth="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.1 1.18 2 2 0 012.11 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 7.09a16 16 0 006 6l.45-.45a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
                </div>
                <div>
                  <div style={{ fontWeight:700, fontSize:13, color:C.texto, marginBottom:4 }}>Teléfono</div>
                  <a href={`tel:${NEGOCIO.telefono}`} style={{ color:C.verdeMedio, fontWeight:700, textDecoration:"none", fontSize:17 }}>{NEGOCIO.telefonoDisplay}</a>
                </div>
              </div>
              {/* Horarios */}
              <div style={{ background:"white", borderRadius:16, padding:22, boxShadow:"0 2px 16px rgba(30,70,40,.06)" }}>
                <div style={{ display:"flex", gap:14, marginBottom:16 }}>
                  <div style={{ width:44, height:44, borderRadius:"50%", background:C.verdeClaro, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                    <svg width="20" height="20" fill="none" stroke={C.verdeMedio} strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                  </div>
                  <div style={{ fontWeight:700, fontSize:13, color:C.texto, alignSelf:"center" }}>Horarios de atención</div>
                </div>
                {HORARIOS.map(h => (
                  <div key={h.dias} style={{ display:"flex", justifyContent:"space-between", padding:"10px 0", borderBottom:"1px solid #f0ede6" }}>
                    <span style={{ color:C.textoSuave, fontSize:14 }}>{h.dias}</span>
                    <span style={{ fontWeight:700, color:C.texto, fontSize:14 }}>{h.horas}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Mapa */}
            <div style={{ borderRadius:20, overflow:"hidden", boxShadow:"0 8px 32px rgba(30,70,40,.1)", height:440 }}>
              <iframe title="Mapa Vivero Garden Center Marysia" src={NEGOCIO.mapsEmbed}
                width="100%" height="100%" style={{ border:0, display:"block" }} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade"/>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          CTA FINAL
      ══════════════════════════════════════ */}
      <section style={{ padding:"72px 24px", background:C.verde, textAlign:"center", position:"relative", overflow:"hidden" }}>
        <div style={{ position:"absolute", top:-60, left:"50%", transform:"translateX(-50%)", width:360, height:360, borderRadius:"50%", background:"radial-gradient(circle,rgba(201,168,76,.1),transparent 70%)", pointerEvents:"none" }}/>
        <div style={{ position:"relative", zIndex:1, maxWidth:580, margin:"0 auto" }}>
          <h2 style={{ fontFamily:"'Playfair Display',serif", fontSize:"clamp(28px,4vw,44px)", fontWeight:700, color:"white", lineHeight:1.2, marginBottom:14 }}>
            ¿Listo para transformar<br/>tu <span style={{ color:"#c9a84c" }}>jardín?</span>
          </h2>
          <p style={{ color:"rgba(255,255,255,.6)", fontSize:17, lineHeight:1.7, marginBottom:36 }}>
            Visítanos en Texcoco o escríbenos ahora. La planta perfecta para tu espacio te está esperando.
          </p>
          <div style={{ display:"flex", gap:14, justifyContent:"center", flexWrap:"wrap" }}>
            <a href={wa} target="_blank" rel="noopener noreferrer" className="btn-gold" style={{ fontSize:16, padding:"15px 30px" }}>Cotizar por WhatsApp</a>
            <a href={`tel:${NEGOCIO.telefono}`} className="btn-outline-w" style={{ fontSize:16, padding:"15px 30px" }}>Llamar ahora</a>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════
          FOOTER
      ══════════════════════════════════════ */}
      <footer style={{ background:"#0c180c", padding:"44px 24px 28px" }}>
        <div style={{ maxWidth:1200, margin:"0 auto" }}>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))", gap:36, paddingBottom:36, borderBottom:"1px solid rgba(255,255,255,.06)" }}>
            {/* Marca */}
            <div>
              <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:14 }}>
                <svg width="34" height="34" viewBox="0 0 40 40" fill="none">
                  <path d="M20 3C20 3 34 8 34 20C34 30 27 37 20 37C13 37 6 30 6 20C6 8 20 3 20 3Z" fill="#c9a84c" fillOpacity="0.18"/>
                  <path d="M20 6C20 6 32 11 32 20C32 28.5 26.5 35 20 35C13.5 35 8 28.5 8 20C8 11 20 6 20 6Z" fill="none" stroke="#c9a84c" strokeWidth="1.2"/>
                  <line x1="20" y1="10" x2="20" y2="33" stroke="#c9a84c" strokeWidth="0.8" strokeDasharray="2 2" opacity="0.6"/>
                </svg>
                <div>
                  <div style={{ fontFamily:"'Playfair Display',serif", color:"white", fontSize:13, fontWeight:700 }}>Garden Center</div>
                  <div style={{ color:"#c9a84c", fontSize:9, fontWeight:700, letterSpacing:"0.2em", textTransform:"uppercase" }}>Marysia</div>
                </div>
              </div>
              <p style={{ color:"rgba(255,255,255,.38)", fontSize:13, lineHeight:1.7 }}>Tu vivero de confianza en Texcoco. Calidad, variedad y atención personalizada.</p>
            </div>

            {/* Nav */}
            <div>
              <div style={{ color:"rgba(255,255,255,.5)", fontWeight:700, fontSize:11, marginBottom:14, letterSpacing:"0.1em", textTransform:"uppercase" }}>Navegación</div>
              {[["Inicio","inicio"],["Nosotros","nosotros"],["Productos","productos"],["Cómo trabajamos","como-trabajamos"],["Galería","galeria"],["Contacto","contacto"]].map(([l,id]) => (
                <button key={id} onClick={() => ir(id)}
                  style={{ display:"block", background:"none", border:"none", cursor:"pointer", color:"rgba(255,255,255,.38)", fontSize:13, padding:"5px 0", textAlign:"left", transition:"color .2s" }}
                  onMouseEnter={e => (e.currentTarget.style.color="#c9a84c")}
                  onMouseLeave={e => (e.currentTarget.style.color="rgba(255,255,255,.38)")}>{l}</button>
              ))}
            </div>

            {/* Contacto */}
            <div>
              <div style={{ color:"rgba(255,255,255,.5)", fontWeight:700, fontSize:11, marginBottom:14, letterSpacing:"0.1em", textTransform:"uppercase" }}>Contacto</div>
              <div style={{ color:"rgba(255,255,255,.38)", fontSize:13, lineHeight:2 }}>{NEGOCIO.direccion}</div>
              <a href={`tel:${NEGOCIO.telefono}`} style={{ color:"#c9a84c", textDecoration:"none", fontSize:14, fontWeight:600, display:"block", marginTop:6 }}>{NEGOCIO.telefonoDisplay}</a>
              <a href={wa} target="_blank" rel="noopener noreferrer"
                style={{ display:"inline-flex", alignItems:"center", gap:7, marginTop:14, background:"rgba(37,211,102,.1)", color:"#25d366", padding:"7px 14px", borderRadius:50, fontSize:12, fontWeight:600, textDecoration:"none", border:"1px solid rgba(37,211,102,.22)" }}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.124.558 4.118 1.531 5.847L.057 23.882l6.198-1.624A11.937 11.937 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-4.999-1.368l-.359-.213-3.678.964.981-3.585-.233-.369A9.812 9.812 0 012.182 12C2.182 6.566 6.566 2.182 12 2.182S21.818 6.566 21.818 12 17.434 21.818 12 21.818z"/></svg>
                WhatsApp
              </a>
            </div>
          </div>
          <div style={{ paddingTop:24, display:"flex", justifyContent:"space-between", flexWrap:"wrap", gap:10 }}>
            <span style={{ color:"rgba(255,255,255,.2)", fontSize:12 }}>© {new Date().getFullYear()} Garden Center Marysia. Todos los derechos reservados.</span>
            <span style={{ color:"rgba(255,255,255,.18)", fontSize:12 }}>Texcoco, Estado de México</span>
          </div>
        </div>
      </footer>

      {/* ══════════════════════════════════════
          BOTÓN FLOTANTE WHATSAPP
      ══════════════════════════════════════ */}
      <a href={wa} target="_blank" rel="noopener noreferrer" className="wa-btn"
        aria-label="Contactar por WhatsApp"
        style={{ position:"fixed", bottom:26, right:26, zIndex:999, width:58, height:58, borderRadius:"50%", background:"#25d366", display:"flex", alignItems:"center", justifyContent:"center", textDecoration:"none", transition:"transform .25s" }}>
        <svg width="29" height="29" viewBox="0 0 24 24" fill="white">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413z"/>
          <path d="M12 0C5.373 0 0 5.373 0 12c0 2.124.558 4.118 1.531 5.847L.057 23.882l6.198-1.624A11.937 11.937 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 01-4.999-1.368l-.359-.213-3.678.964.981-3.585-.233-.369A9.812 9.812 0 012.182 12C2.182 6.566 6.566 2.182 12 2.182S21.818 6.566 21.818 12 17.434 21.818 12 21.818z"/>
        </svg>
      </a>

    </div>
  )
}
