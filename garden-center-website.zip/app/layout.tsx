import type { Metadata } from 'next'
import { Plus_Jakarta_Sans, Playfair_Display } from 'next/font/google'
import './globals.css'

/* ============================================
   FUENTES
   Plus Jakarta Sans = cuerpo (moderno, legible)
   Playfair Display  = títulos (elegante, premium)
   ============================================ */
const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
  weight: ['400', '500', '600', '700'],
})

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-serif',
  display: 'swap',
  weight: ['400', '500', '700'],
})

/* ============================================
   SEO LOCAL — Texcoco, Estado de México
   Edita aquí los metadatos del sitio
   ============================================ */
export const metadata: Metadata = {
  title: 'Vivero Garden Center Marysia | Plantas y Árboles en Texcoco',
  description:
    'Vivero en Texcoco, Estado de México. Vendemos plantas ornamentales, árboles frutales, macetas, tierra y sustratos. Visítanos en Carr al Molino de Flores 8, Xocotlan. Tel: 595 954 4223.',
  keywords: [
    'vivero Texcoco',
    'plantas Texcoco',
    'árboles frutales Estado de México',
    'vivero Garden Center Marysia',
    'plantas ornamentales',
    'jardinería Texcoco',
    'macetas Texcoco',
    'tierra para plantas',
  ],
  openGraph: {
    title: 'Vivero Garden Center Marysia — Texcoco',
    description:
      'Tu vivero de confianza en Texcoco. Plantas, árboles, macetas y asesoría personalizada.',
    locale: 'es_MX',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es-MX" className="bg-background scroll-smooth">
      <body className={`${plusJakarta.variable} ${playfair.variable} font-sans antialiased`}>
        {children}
      </body>
    </html>
  )
}
