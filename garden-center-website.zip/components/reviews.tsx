'use client'

/**
 * RESEÑAS — Vivero Garden Center Marysia
 * ────────────────────────────────────────
 * • Carrusel de reseñas de clientes (simuladas / reales)
 * • Rating visual con estrellas
 * • Badge de Google Maps
 * • Navegación por puntos
 *
 * PARA EDITAR: Modifica el array REVIEWS abajo.
 */

import { useState, useEffect } from 'react'

/* ====================================================
   DATOS EDITABLES — Reemplaza con reseñas reales
   ==================================================== */
const REVIEWS = [
  {
    name: 'Lorena García',
    initials: 'LG',
    rating: 5,
    date: 'Hace 2 semanas',
    text: '¡Excelente vivero! Fui buscando unas plantas para mi sala y salí con mucho más de lo esperado. El trato es muy amable y los precios son justos. Las plantas llegaron super saludables a mi casa. Definitivamente regreso.',
    color: 'bg-emerald-600',
  },
  {
    name: 'Roberto Sánchez',
    initials: 'RS',
    rating: 5,
    date: 'Hace 1 mes',
    text: 'Llevo años comprando aquí mis árboles frutales. Tengo limones, naranjas y un aguacate que compré hace 3 años y ya da fruto. La calidad de las plantas es notoria. El personal siempre sabe orientarte bien.',
    color: 'bg-teal-600',
  },
  {
    name: 'Martha Delgado',
    initials: 'MD',
    rating: 5,
    date: 'Hace 3 semanas',
    text: 'Muy buen lugar para encontrar de todo. Macetas, tierra, plantas ornamentales y más. Lo que más me gustó es que te explican cómo cuidar cada planta. Muy recomendable para quienes están empezando en jardinería.',
    color: 'bg-amber-600',
  },
  {
    name: 'Carlos Hernández',
    initials: 'CH',
    rating: 4,
    date: 'Hace 2 meses',
    text: 'Buen vivero con mucha variedad. Compré varias suculentas y un helecho y todos están perfectos. La atención es personalizada, te dedican tiempo para elegir bien. El único detalle es que los fines de semana está muy concurrido.',
    color: 'bg-[var(--primary)]',
  },
  {
    name: 'Ana María Torres',
    initials: 'AM',
    rating: 5,
    date: 'Hace 5 días',
    text: 'Increíble variedad y todo muy bien cuidado. Vine de Texcoco específicamente por la reputación del vivero y no me decepcionó. Las plantas de interior que compré están hermosas. El precio es muy razonable para la calidad.',
    color: 'bg-violet-600',
  },
]

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5" role="img" aria-label={`${rating} de 5 estrellas`}>
      {[1, 2, 3, 4, 5].map((star) => (
        <svg
          key={star}
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill={star <= rating ? 'var(--gold)' : 'none'}
          stroke="var(--gold)"
          strokeWidth="1.5"
          aria-hidden="true"
        >
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
        </svg>
      ))}
    </div>
  )
}

export default function Reviews() {
  const [current, setCurrent] = useState(0)
  const [isAutoplay, setIsAutoplay] = useState(true)

  useEffect(() => {
    if (!isAutoplay) return
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % REVIEWS.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [isAutoplay])

  const handleDotClick = (i: number) => {
    setCurrent(i)
    setIsAutoplay(false)
  }

  // Índices para mostrar 3 tarjetas en desktop
  const visibleIndexes = [
    (current - 1 + REVIEWS.length) % REVIEWS.length,
    current,
    (current + 1) % REVIEWS.length,
  ]

  return (
    <section
      className="py-20 sm:py-28 bg-[var(--section-cream)]"
      aria-labelledby="reviews-heading"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-12">
          <div>
            <span className="inline-block text-[var(--accent)] font-semibold text-sm uppercase tracking-widest mb-3">
              Clientes felices
            </span>
            <h2
              id="reviews-heading"
              className="font-serif text-3xl sm:text-4xl font-bold text-foreground text-balance"
            >
              Lo que dicen nuestros clientes
            </h2>
          </div>
          {/* Rating general */}
          <div className="flex items-center gap-3 bg-card border border-border rounded-2xl px-5 py-3 shadow-sm flex-shrink-0">
            <div className="text-center">
              <p className="font-serif font-bold text-3xl text-[var(--primary)] leading-none">4.5</p>
              <StarRating rating={5} />
              <p className="text-muted-foreground text-xs mt-1">en Google Maps</p>
            </div>
            <div className="w-px h-10 bg-border mx-1" aria-hidden="true" />
            <div className="text-center">
              <p className="font-bold text-lg text-foreground leading-none">+80</p>
              <p className="text-muted-foreground text-xs mt-1">reseñas</p>
            </div>
          </div>
        </div>

        {/* Carrusel — desktop muestra 3, mobile 1 */}
        <div className="overflow-hidden">
          {/* Mobile: un solo review */}
          <div className="block md:hidden">
            <ReviewCard review={REVIEWS[current]} isCenter={true} />
          </div>

          {/* Desktop: 3 reviews */}
          <div className="hidden md:grid md:grid-cols-3 gap-5">
            {visibleIndexes.map((idx, pos) => (
              <ReviewCard
                key={idx}
                review={REVIEWS[idx]}
                isCenter={pos === 1}
              />
            ))}
          </div>
        </div>

        {/* Dot navigation */}
        <div className="flex items-center justify-center gap-2 mt-8" role="tablist" aria-label="Navegar reseñas">
          {REVIEWS.map((_, i) => (
            <button
              key={i}
              onClick={() => handleDotClick(i)}
              role="tab"
              aria-selected={i === current}
              aria-label={`Ir a reseña ${i + 1}`}
              className={`rounded-full transition-all duration-300 ${
                i === current
                  ? 'w-7 h-2.5 bg-[var(--primary)]'
                  : 'w-2.5 h-2.5 bg-[var(--primary)]/25 hover:bg-[var(--primary)]/50'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  )
}

function ReviewCard({
  review,
  isCenter,
}: {
  review: (typeof REVIEWS)[0]
  isCenter: boolean
}) {
  return (
    <div
      className={`bg-card rounded-2xl p-6 border border-border transition-all duration-300 ${
        isCenter ? 'shadow-nature scale-[1.02] border-[var(--primary)]/20' : 'opacity-80'
      }`}
    >
      {/* Cabecera */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-full ${review.color} text-white flex items-center justify-center font-semibold text-sm flex-shrink-0`}
            aria-hidden="true"
          >
            {review.initials}
          </div>
          <div>
            <p className="font-semibold text-foreground text-sm leading-tight">{review.name}</p>
            <p className="text-muted-foreground text-xs mt-0.5">{review.date}</p>
          </div>
        </div>
        {/* Logo Google */}
        <svg width="18" height="18" viewBox="0 0 24 24" aria-label="Google" role="img">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
      </div>

      <StarRating rating={review.rating} />

      <p className="text-muted-foreground text-sm leading-relaxed mt-3">
        &ldquo;{review.text}&rdquo;
      </p>
    </div>
  )
}
