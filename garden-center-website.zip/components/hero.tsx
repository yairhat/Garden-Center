'use client'

/**
 * HERO SECTION — Vivero Garden Center Marysia
 * ─────────────────────────────────────────────
 * • Imagen de fondo full-screen con overlay oscuro
 * • Headline principal + subtítulo persuasivo
 * • Dos CTA: llamar y WhatsApp
 * • Indicadores de confianza (stats rápidos)
 * • Scroll indicator animado
 *
 * PARA EDITAR:
 * • Cambia HEADLINE, SUBHEADLINE y STATS abajo
 * • Reemplaza la URL del img src con tu foto real
 */

import { useEffect, useState } from 'react'

/* ====================================================
   DATOS EDITABLES
   ==================================================== */
const PHONE = '5959544223'
const PHONE_DISPLAY = '595 954 4223'
const WHATSAPP_MSG = 'Hola, me interesa conocer sus plantas y servicios. ¿Pueden ayudarme?'

const HEADLINE = 'Tu jardín merece lo mejor'
const SUBHEADLINE =
  'Más de 20 años cuidando la naturaleza en Texcoco. Encontrarás plantas, árboles y todo lo que necesitas para transformar tus espacios verdes.'

const STATS = [
  { value: '+500', label: 'Variedades' },
  { value: '20+', label: 'Años de exp.' },
  { value: '4.5★', label: 'Calificación' },
  { value: '100%', label: 'Atención personal' },
]

export default function Hero() {
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    // Pequeño delay para que la animación de entrada sea visible
    const t = setTimeout(() => setLoaded(true), 100)
    return () => clearTimeout(t)
  }, [])

  const whatsappUrl = `https://wa.me/52${PHONE}?text=${encodeURIComponent(WHATSAPP_MSG)}`

  return (
    <section
      id="inicio"
      className="relative min-h-screen flex flex-col justify-end overflow-hidden"
      aria-label="Sección principal"
    >
      {/* ── Imagen de fondo ── */}
      <img
        src="https://placehold.co/1920x1080?text=Vivero+lleno+de+plantas+verdes+tropicales+y+ornamentales+con+luz+natural+calida"
        alt="Interior del Vivero Garden Center Marysia con abundantes plantas ornamentales y tropicales"
        className="absolute inset-0 w-full h-full object-cover object-center"
        loading="eager"
        fetchPriority="high"
      />

      {/* ── Overlay verde oscuro degradado ── */}
      <div className="absolute inset-0 hero-overlay" aria-hidden="true" />

      {/* ── Patrón de textura sutil ── */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `radial-gradient(circle, white 1px, transparent 1px)`,
          backgroundSize: '28px 28px',
        }}
        aria-hidden="true"
      />

      {/* ── Contenido principal ── */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 pb-16 pt-32 w-full">
        <div
          className={`max-w-2xl transition-all duration-700 ${
            loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Badge */}
          <span className="inline-flex items-center gap-2 px-3 py-1.5 bg-[var(--gold)]/20 border border-[var(--gold)]/40 text-[var(--gold)] text-xs font-semibold rounded-full mb-5 backdrop-blur-sm tracking-wide uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--gold)] animate-pulse" aria-hidden="true" />
            Texcoco, Estado de México
          </span>

          {/* Headline */}
          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight text-balance mb-4">
            {HEADLINE}
          </h1>

          {/* Subheadline */}
          <p className="text-white/80 text-lg sm:text-xl leading-relaxed mb-8 text-pretty max-w-xl">
            {SUBHEADLINE}
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            {/* WhatsApp */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center justify-center gap-3 px-7 py-4 bg-[#25D366] text-white font-semibold rounded-full shadow-lg hover:bg-[#20B858] transition-all duration-300 hover:scale-105 hover:shadow-xl text-base"
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.63"/>
              </svg>
              Enviar WhatsApp
            </a>

            {/* Llamar */}
            <a
              href={`tel:${PHONE}`}
              className="flex items-center justify-center gap-3 px-7 py-4 bg-white/10 backdrop-blur-sm text-white font-semibold rounded-full border border-white/30 hover:bg-white/20 transition-all duration-300 hover:scale-105 text-base"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1-9.4 0-17-7.6-17-17 0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z"/>
              </svg>
              Llamar ahora
            </a>
          </div>
        </div>

        {/* ── Stats rápidos ── */}
        <div
          className={`mt-12 grid grid-cols-2 md:grid-cols-4 gap-px bg-white/10 rounded-2xl overflow-hidden backdrop-blur-sm border border-white/10 transition-all duration-700 delay-300 ${
            loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          {STATS.map((stat, i) => (
            <div
              key={i}
              className="flex flex-col items-center justify-center py-4 px-3 bg-black/20 hover:bg-black/10 transition-colors duration-200"
            >
              <span className="font-serif font-bold text-[var(--gold)] text-2xl sm:text-3xl leading-none">
                {stat.value}
              </span>
              <span className="text-white/65 text-xs font-medium mt-1 text-center leading-tight">
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* ── Scroll indicator ── */}
      <div
        className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 opacity-60"
        aria-hidden="true"
      >
        <span className="text-white text-xs tracking-widest uppercase">Descubre más</span>
        <div className="w-5 h-8 rounded-full border border-white/50 flex items-start justify-center pt-1.5">
          <div className="w-1 h-2 bg-white rounded-full animate-bounce" />
        </div>
      </div>

      {/* ── Curva inferior ── */}
      <div className="absolute -bottom-1 left-0 right-0 overflow-hidden leading-none" aria-hidden="true">
        <svg
          viewBox="0 0 1440 70"
          preserveAspectRatio="none"
          className="w-full h-12 sm:h-16 md:h-[70px]"
          fill="var(--background)"
        >
          <path d="M0,40 C360,80 1080,0 1440,40 L1440,70 L0,70 Z" />
        </svg>
      </div>
    </section>
  )
}
