'use client'

/**
 * SECCIÓN PRODUCTOS — Vivero Garden Center Marysia
 * ──────────────────────────────────────────────────
 * • Tarjetas de productos/servicios con imágenes
 * • Hover effects sutiles
 * • CTA al final de sección
 *
 * PARA EDITAR: Modifica el array PRODUCTS abajo.
 * Cada objeto tiene: title, desc, image, imageAlt, tag (opcional)
 */

import { useState } from 'react'

/* ====================================================
   DATOS EDITABLES — Agrega, quita o edita productos
   ==================================================== */
const PRODUCTS = [
  {
    title: 'Plantas Ornamentales',
    desc: 'Helechos, pothos, anturios, begonias, crotons y muchas más. Perfectas para interiores y jardines. Las mejores opciones para dar vida a cualquier rincón.',
    image: 'https://placehold.co/600x400?text=Plantas+ornamentales+coloridas+con+hojas+exuberantes+en+macetas+de+barro',
    imageAlt: 'Variedad de plantas ornamentales coloridas con hojas exuberantes en macetas de barro',
    tag: 'Más vendido',
    tagColor: 'bg-[var(--gold)] text-[var(--gold-foreground)]',
  },
  {
    title: 'Árboles Frutales',
    desc: 'Limón, naranja, durazno, aguacate, manzano y más variedades. Planta tu propia huerta y disfruta de frutos naturales todo el año.',
    image: 'https://placehold.co/600x400?text=Arboles+frutales+jovenes+con+frutos+naranjas+y+limones+en+vivero+al+aire+libre',
    imageAlt: 'Árboles frutales jóvenes con frutos de naranja y limón listos para plantar',
    tag: 'Populares',
    tagColor: 'bg-[var(--primary)] text-[var(--primary-foreground)]',
  },
  {
    title: 'Macetas y Contenedores',
    desc: 'Amplio catálogo de macetas de barro, plástico, cerámica y fibra. Todos los tamaños para cada planta y decoración.',
    image: 'https://placehold.co/600x400?text=Coleccion+de+macetas+de+barro+ceramica+y+plastico+de+diferentes+tamanos+colores',
    imageAlt: 'Colección de macetas de barro, cerámica y plástico de diferentes tamaños y colores',
    tag: null,
    tagColor: '',
  },
  {
    title: 'Tierra y Sustratos',
    desc: 'Tierra negra, composta, perlita, tezontle, sustrato universal y mezclas especiales para cactus, orquídeas y más.',
    image: 'https://placehold.co/600x400?text=Sacos+de+tierra+negra+sustrato+y+composta+para+plantas+en+bodega+de+vivero',
    imageAlt: 'Sacos de tierra negra, sustrato y composta de alta calidad para plantas',
    tag: null,
    tagColor: '',
  },
  {
    title: 'Suculentas y Cactus',
    desc: 'La tendencia que nunca pasa de moda. Tenemos cientos de variedades de suculentas y cactus para coleccionistas y principiantes.',
    image: 'https://placehold.co/600x400?text=Coleccion+de+suculentas+y+cactus+pequenos+en+macetas+minimalistas+luz+suave',
    imageAlt: 'Colección de suculentas y cactus pequeños en macetas minimalistas con luz suave',
    tag: 'Tendencia',
    tagColor: 'bg-[var(--earth)] text-[var(--earth-foreground)]',
  },
  {
    title: 'Asesoría de Jardinería',
    desc: 'No sabes qué planta elegir o cómo cuidarla? Nuestro equipo te orienta sin costo adicional. Llevamos años aprendiendo para ayudarte mejor.',
    image: 'https://placehold.co/600x400?text=Experto+en+jardineria+asesorando+cliente+en+vivero+rodeado+de+plantas+verdes',
    imageAlt: 'Experto en jardinería asesorando a un cliente entre plantas en el vivero',
    tag: 'Gratis',
    tagColor: 'bg-emerald-500 text-white',
  },
]

const PHONE = '5959544223'
const WHATSAPP_MSG = '¡Hola! Me gustaría cotizar productos del vivero.'

export default function Products() {
  const [activeCard, setActiveCard] = useState<number | null>(null)
  const whatsappUrl = `https://wa.me/52${PHONE}?text=${encodeURIComponent(WHATSAPP_MSG)}`

  return (
    <section
      id="productos"
      className="py-20 sm:py-28 bg-[var(--section-cream)]"
      aria-labelledby="products-heading"
    >
      {/* Curva superior */}
      <div className="w-full overflow-hidden leading-none -mt-20 mb-0" aria-hidden="true">
        <svg viewBox="0 0 1440 70" preserveAspectRatio="none" className="w-full h-12 sm:h-16 fill-[var(--section-cream)]">
          <path d="M0,70 C480,0 960,70 1440,0 L1440,70 L0,70 Z"/>
        </svg>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-14">
          <span className="inline-block text-[var(--accent)] font-semibold text-sm uppercase tracking-widest mb-3">
            Lo que ofrecemos
          </span>
          <h2
            id="products-heading"
            className="font-serif text-3xl sm:text-4xl font-bold text-foreground text-balance mb-4"
          >
            Todo para tu jardín en un solo lugar
          </h2>
          <p className="text-muted-foreground text-base max-w-xl mx-auto leading-relaxed">
            Desde plantas de interior hasta árboles frutales, macetas y sustratos. Encontrarás todo lo que necesitas para crear y mantener espacios verdes hermosos.
          </p>
        </div>

        {/* Grid de productos */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {PRODUCTS.map((product, i) => (
            <article
              key={i}
              onMouseEnter={() => setActiveCard(i)}
              onMouseLeave={() => setActiveCard(null)}
              className={`group bg-card rounded-2xl overflow-hidden border transition-all duration-300 cursor-pointer ${
                activeCard === i
                  ? 'border-[var(--primary)]/30 -translate-y-2 shadow-[0_20px_48px_-8px_oklch(0.25_0.07_142_/_0.25)]'
                  : 'border-border shadow-[0_2px_12px_0_oklch(0.25_0.07_142_/_0.07)]'
              }`}
            >
              {/* Imagen */}
              <div className="relative overflow-hidden aspect-[3/2]">
                <img
                  src={product.image}
                  alt={product.imageAlt}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                {product.tag && (
                  <span
                    className={`absolute top-3 left-3 px-2.5 py-1 text-xs font-semibold rounded-full ${product.tagColor}`}
                  >
                    {product.tag}
                  </span>
                )}
              </div>

              {/* Contenido */}
              <div className="p-5">
                <h3 className="font-semibold text-foreground text-base mb-2 group-hover:text-[var(--primary)] transition-colors duration-200">
                  {product.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                  {product.desc}
                </p>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-[var(--primary)] font-semibold text-sm hover:gap-2.5 transition-all duration-200"
                >
                  Cotizar por WhatsApp
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                  </svg>
                </a>
              </div>
            </article>
          ))}
        </div>

        {/* CTA central */}
        <div className="text-center mt-12">
          <p className="text-muted-foreground text-sm mb-4">
            ¿No encuentras lo que buscas? Contáctanos, tenemos mucho más en el vivero.
          </p>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-8 py-4 bg-[var(--primary)] text-[var(--primary-foreground)] font-semibold rounded-full shadow-lg hover:bg-[var(--primary)]/85 transition-all duration-300 hover:scale-105 hover:shadow-xl"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.63"/>
            </svg>
            Consultar disponibilidad
          </a>
        </div>
      </div>
    </section>
  )
}
