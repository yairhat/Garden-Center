'use client'

/**
 * GALERÍA — Vivero Garden Center Marysia
 * ────────────────────────────────────────
 * • Grid Masonry-style responsivo
 * • Lightbox al hacer click en cada imagen
 * • Cierre con tecla Esc o click afuera
 *
 * PARA EDITAR: Reemplaza los src de GALLERY_IMAGES
 * con tus fotos reales del vivero.
 */

import { useState, useEffect, useCallback } from 'react'

/* ====================================================
   DATOS EDITABLES — Reemplaza con fotos reales
   ==================================================== */
const GALLERY_IMAGES = [
  {
    src: 'https://placehold.co/800x600?text=Entrada+del+vivero+con+arreglos+florales+y+plantas+en+macetas+coloridas',
    alt: 'Entrada del Vivero Garden Center Marysia con arreglos florales y plantas en macetas coloridas',
    span: 'col-span-2 row-span-2',
  },
  {
    src: 'https://placehold.co/600x400?text=Seccion+de+arboles+frutales+con+naranjos+y+limoneros+en+el+vivero',
    alt: 'Sección de árboles frutales con naranjos y limoneros',
    span: '',
  },
  {
    src: 'https://placehold.co/600x400?text=Plantas+tropicales+de+hoja+grande+monstera+y+helechos+en+exhibicion',
    alt: 'Plantas tropicales de hoja grande tipo monstera y helechos en exhibición',
    span: '',
  },
  {
    src: 'https://placehold.co/600x600?text=Suculentas+variadas+en+macetas+de+ceramica+blanca+sobre+mesa+de+madera',
    alt: 'Suculentas variadas en macetas de cerámica blanca sobre mesa de madera',
    span: '',
  },
  {
    src: 'https://placehold.co/600x400?text=Vista+panoramica+del+vivero+con+pasillos+verdes+y+plantas+ordenadas',
    alt: 'Vista panorámica del vivero con pasillos verdes y plantas perfectamente ordenadas',
    span: 'col-span-2',
  },
  {
    src: 'https://placehold.co/600x400?text=Macetas+de+barro+artesanal+de+diferentes+tamanos+apiladas+en+vivero',
    alt: 'Macetas de barro artesanal de diferentes tamaños apiladas en el vivero',
    span: '',
  },
]

export default function Gallery() {
  const [lightbox, setLightbox] = useState<number | null>(null)

  const close = useCallback(() => setLightbox(null), [])
  const prev = useCallback(() =>
    setLightbox((cur) => (cur !== null ? (cur - 1 + GALLERY_IMAGES.length) % GALLERY_IMAGES.length : null)),
    []
  )
  const next = useCallback(() =>
    setLightbox((cur) => (cur !== null ? (cur + 1) % GALLERY_IMAGES.length : null)),
    []
  )

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close()
      if (e.key === 'ArrowLeft') prev()
      if (e.key === 'ArrowRight') next()
    }
    if (lightbox !== null) {
      document.addEventListener('keydown', handleKey)
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => {
      document.removeEventListener('keydown', handleKey)
      document.body.style.overflow = ''
    }
  }, [lightbox, close, prev, next])

  return (
    <section
      id="galeria"
      className="py-20 sm:py-28 bg-[var(--hero-bg)]"
      aria-labelledby="gallery-heading"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="inline-block text-[var(--gold)] font-semibold text-sm uppercase tracking-widest mb-3">
            Nuestro vivero
          </span>
          <h2
            id="gallery-heading"
            className="font-serif text-3xl sm:text-4xl font-bold text-white text-balance mb-4"
          >
            Ven y descubre nuestra variedad
          </h2>
          <p className="text-white/60 text-base max-w-lg mx-auto leading-relaxed">
            Cada rincón de nuestro vivero está lleno de vida, color y naturaleza. Visítanos y déjate sorprender.
          </p>
        </div>

        {/* Grid */}
        <div
          className="grid grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4"
          role="list"
          aria-label="Galería de fotos del vivero"
        >
          {GALLERY_IMAGES.map((img, i) => (
            <div
              key={i}
              role="listitem"
              className={`${img.span} relative overflow-hidden rounded-xl cursor-pointer group`}
              onClick={() => setLightbox(i)}
              onKeyDown={(e) => e.key === 'Enter' && setLightbox(i)}
              tabIndex={0}
              aria-label={`Ver imagen: ${img.alt}`}
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  loading="lazy"
                />
              </div>
              {/* Overlay hover */}
              <div className="absolute inset-0 bg-[var(--primary)]/0 group-hover:bg-[var(--primary)]/40 transition-all duration-300 flex items-center justify-center">
                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-white/90 rounded-full p-3">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--hero-bg)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <circle cx="11" cy="11" r="8"/>
                    <path d="m21 21-4.35-4.35M11 8v6M8 11h6"/>
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Nota debajo */}
        <p className="text-center text-white/40 text-xs mt-6">
          Haz click en cualquier imagen para ampliarla
        </p>
      </div>

      {/* ── Lightbox ── */}
      {lightbox !== null && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Visor de imagen"
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={close}
        >
          {/* Contenedor imagen (no cierra al clickear dentro) */}
          <div
            className="relative max-w-4xl w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={GALLERY_IMAGES[lightbox].src}
              alt={GALLERY_IMAGES[lightbox].alt}
              className="w-full h-auto max-h-[80vh] object-contain rounded-xl shadow-2xl"
            />
            <p className="text-white/60 text-sm text-center mt-3">
              {GALLERY_IMAGES[lightbox].alt}
            </p>

            {/* Botón cerrar */}
            <button
              onClick={close}
              className="absolute -top-3 -right-3 w-9 h-9 rounded-full bg-white/20 hover:bg-white/35 text-white flex items-center justify-center transition-colors duration-200"
              aria-label="Cerrar imagen"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true">
                <path d="M18 6 6 18M6 6l12 12"/>
              </svg>
            </button>

            {/* Prev / Next */}
            <button
              onClick={(e) => { e.stopPropagation(); prev() }}
              className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/35 text-white flex items-center justify-center transition-colors duration-200"
              aria-label="Imagen anterior"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true">
                <path d="M15 18l-6-6 6-6"/>
              </svg>
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); next() }}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/35 text-white flex items-center justify-center transition-colors duration-200"
              aria-label="Imagen siguiente"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true">
                <path d="M9 18l6-6-6-6"/>
              </svg>
            </button>

            {/* Contador */}
            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 bg-black/60 text-white text-xs px-3 py-1 rounded-full">
              {lightbox + 1} / {GALLERY_IMAGES.length}
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
