'use client'

/**
 * NAVBAR — Vivero Garden Center Marysia
 * ─────────────────────────────────────
 * • Logo + nombre del negocio (edita BUSINESS_NAME y PHONE)
 * • Links de navegación suave (scroll)
 * • Botón CTA principal visible en desktop
 * • Menú hamburguesa para mobile
 * • Se vuelve opaco al hacer scroll (efecto glass)
 */

import { useState, useEffect } from 'react'

/* ====================================================
   DATOS EDITABLES — Cambia aquí sin tocar el resto
   ==================================================== */
const PHONE = '5959544223'           // Sin espacios ni guiones
const PHONE_DISPLAY = '595 954 4223' // Formato visual
const WHATSAPP_MSG = 'Hola, me gustaría obtener más información sobre sus plantas y servicios.'

const NAV_LINKS = [
  { label: 'Inicio', href: '#inicio' },
  { label: 'Nosotros', href: '#nosotros' },
  { label: 'Productos', href: '#productos' },
  { label: 'Cómo trabajamos', href: '#como-trabajamos' },
  { label: 'Plantas especiales', href: '#plantas-especiales' },
  { label: 'Galería', href: '#galeria' },
  { label: 'Contacto', href: '#contacto' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const handleNavClick = (href: string) => {
    setOpen(false)
    const el = document.querySelector(href)
    if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  const whatsappUrl = `https://wa.me/52${PHONE}?text=${encodeURIComponent(WHATSAPP_MSG)}`

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-[var(--hero-bg)]/40 backdrop-blur-xl backdrop-saturate-150 border-b border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.18)] py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <nav
        className="max-w-6xl mx-auto px-4 sm:px-6 flex items-center justify-between"
        aria-label="Navegación principal"
      >
        {/* ── Logo ── */}
        <button
          onClick={() => handleNavClick('#inicio')}
          className="flex items-center gap-3 group"
          aria-label="Ir al inicio"
        >
          {/* Logomark: hoja geométrica + inicial */}
          <span className="relative w-10 h-10 flex-shrink-0 group-hover:scale-105 transition-transform duration-300" aria-hidden="true">
            {/* Hexágono suave de fondo */}
            <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
              {/* Fondo dorado en forma de hoja/escudo redondeado */}
              <path
                d="M20 3 C20 3 34 8 34 20 C34 30 27 37 20 37 C13 37 6 30 6 20 C6 8 20 3 20 3Z"
                fill="var(--gold)"
                opacity="0.18"
              />
              {/* Hoja principal */}
              <path
                d="M20 6 C20 6 32 11 32 20 C32 28.5 26.5 35 20 35 C13.5 35 8 28.5 8 20 C8 11 20 6 20 6Z"
                fill="none"
                stroke="var(--gold)"
                strokeWidth="1.2"
              />
              {/* Nervadura central */}
              <line x1="20" y1="10" x2="20" y2="33" stroke="var(--gold)" strokeWidth="0.8" strokeDasharray="2 2" opacity="0.6"/>
              {/* Nervaduras laterales */}
              <line x1="20" y1="16" x2="13" y2="22" stroke="var(--gold)" strokeWidth="0.6" opacity="0.5"/>
              <line x1="20" y1="16" x2="27" y2="22" stroke="var(--gold)" strokeWidth="0.6" opacity="0.5"/>
              <line x1="20" y1="22" x2="14" y2="27" stroke="var(--gold)" strokeWidth="0.6" opacity="0.4"/>
              <line x1="20" y1="22" x2="26" y2="27" stroke="var(--gold)" strokeWidth="0.6" opacity="0.4"/>
            </svg>
          </span>

          {/* Wordmark */}
          <div className="leading-tight text-left">
            <span className="block font-serif font-bold text-white text-[15px] leading-none tracking-tight">
              Garden Center
            </span>
            <div className="flex items-center gap-1.5 mt-[3px]">
              <span className="block text-[var(--gold)] text-[11px] font-semibold tracking-[0.18em] uppercase leading-none">
                Marysia
              </span>
              {/* Punto decorativo */}
              <span className="w-1 h-1 rounded-full bg-[var(--gold)]/50 inline-block" />
              <span className="text-white/35 text-[9px] tracking-wider uppercase leading-none">Vivero</span>
            </div>
          </div>
        </button>

        {/* ── Links desktop ── */}
        <ul className="hidden md:flex items-center gap-1 list-none" role="list">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <button
                onClick={() => handleNavClick(link.href)}
                className="px-3 py-2 text-sm font-medium text-[var(--primary-foreground)]/80 hover:text-[var(--gold)] transition-colors duration-200 rounded-md hover:bg-white/5"
              >
                {link.label}
              </button>
            </li>
          ))}
        </ul>

        {/* ── CTA desktop ── */}
        <div className="hidden md:flex items-center gap-3">
          <a
            href={`tel:${PHONE}`}
            className="flex items-center gap-2 text-[var(--primary-foreground)]/80 hover:text-[var(--gold)] text-sm font-medium transition-colors duration-200"
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
              <path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1-9.4 0-17-7.6-17-17 0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z"/>
            </svg>
            {PHONE_DISPLAY}
          </a>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 bg-[var(--gold)] text-[var(--gold-foreground)] text-sm font-semibold rounded-full hover:bg-[var(--gold)]/85 transition-all duration-200 hover:scale-105 shadow-md"
          >
            WhatsApp
          </a>
        </div>

        {/* ── Hamburguesa mobile ── */}
        <button
          onClick={() => setOpen(!open)}
          className="md:hidden p-2 rounded-lg text-[var(--primary-foreground)] hover:bg-white/10 transition-colors duration-200"
          aria-expanded={open}
          aria-label={open ? 'Cerrar menú' : 'Abrir menú'}
        >
          <span className="sr-only">{open ? 'Cerrar menú' : 'Abrir menú'}</span>
          <div className="w-5 h-4 flex flex-col justify-between">
            <span className={`block h-0.5 w-full bg-current transition-all duration-300 ${open ? 'rotate-45 translate-y-[7px]' : ''}`} />
            <span className={`block h-0.5 w-full bg-current transition-all duration-300 ${open ? 'opacity-0 scale-x-0' : ''}`} />
            <span className={`block h-0.5 w-full bg-current transition-all duration-300 ${open ? '-rotate-45 -translate-y-[9px]' : ''}`} />
          </div>
        </button>
      </nav>

      {/* ── Menú mobile desplegable ── */}
      <div
        className={`md:hidden transition-all duration-300 overflow-hidden ${
          open ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="bg-[var(--hero-bg)]/98 backdrop-blur-md border-t border-white/10 px-4 py-4">
          <ul className="space-y-1 mb-4 list-none" role="list">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <button
                  onClick={() => handleNavClick(link.href)}
                  className="w-full text-left px-3 py-2.5 text-sm font-medium text-[var(--primary-foreground)]/85 hover:text-[var(--gold)] hover:bg-white/5 rounded-lg transition-colors duration-200"
                >
                  {link.label}
                </button>
              </li>
            ))}
          </ul>
          <div className="flex flex-col gap-2 pt-3 border-t border-white/10">
            <a
              href={`tel:${PHONE}`}
              className="flex items-center justify-center gap-2 py-2.5 text-sm font-semibold text-[var(--primary-foreground)] border border-white/20 rounded-full hover:border-[var(--gold)] transition-colors duration-200"
            >
              Llamar: {PHONE_DISPLAY}
            </a>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-2.5 text-sm font-semibold bg-[var(--gold)] text-[var(--gold-foreground)] rounded-full hover:bg-[var(--gold)]/85 transition-colors duration-200"
            >
              Enviar WhatsApp
            </a>
          </div>
        </div>
      </div>
    </header>
  )
}
