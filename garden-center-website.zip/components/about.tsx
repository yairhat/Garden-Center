/**
 * SECCIÓN NOSOTROS — Vivero Garden Center Marysia
 * ─────────────────────────────────────────────────
 * PARA EDITAR: Cambia ABOUT_DATA y TRUST_POINTS abajo
 */

/* ====================================================
   DATOS EDITABLES — Cambia aquí sin tocar el resto
   ==================================================== */
const ABOUT_DATA = {
  eyebrow: 'Nuestro vivero',
  headline: 'Más de 20 años cultivando amor por la naturaleza',
  body: [
    'En Vivero Garden Center Marysia llevamos más de dos décadas siendo el lugar de confianza para familias, jardineros y amantes de las plantas en Texcoco y la región.',
    'Somos un negocio familiar comprometido con ofrecerte las plantas más sanas, la mejor asesoría y precios accesibles. Cada planta que sale de aquí ha sido cuidada con dedicación y conocimiento.',
    'Nos ubicamos en Carr al Molino de Flores 8, Xocotlan — fácil de encontrar y con amplio espacio para que explores toda nuestra variedad.',
  ],
}

const TRUST_POINTS = [
  {
    title: 'Plantas sanas y de calidad',
    desc: 'Seleccionamos cada espécimen para garantizar que llegue a tu hogar en perfectas condiciones.',
  },
  {
    title: 'Atención personalizada',
    desc: 'Nuestro equipo te asesora para elegir la planta perfecta según tu espacio, clima y experiencia.',
  },
  {
    title: 'Negocio familiar confiable',
    desc: 'Somos parte de la comunidad de Texcoco. Tu satisfacción es nuestra mejor publicidad.',
  },
  {
    title: 'Gran variedad de especies',
    desc: 'Más de 500 variedades entre plantas ornamentales, árboles frutales, suculentas y más.',
  },
]

/* Iconos SVG como componentes independientes */
function IconLeaf() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10z" />
      <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12" />
    </svg>
  )
}

function IconClock() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="10" />
      <path d="M12 6v6l4 2" />
    </svg>
  )
}

function IconShield() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
  )
}

function IconCheck() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  )
}

const TRUST_ICONS = [IconLeaf, IconClock, IconShield, IconCheck]

export default function About() {
  return (
    <section
      id="nosotros"
      className="py-20 sm:py-28 bg-background"
      aria-labelledby="about-heading"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* ── Imagen ── */}
          <div className="relative">
            {/* Marco decorativo verde detrás */}
            <div
              className="absolute -inset-3 rounded-3xl -rotate-2"
              style={{ background: 'oklch(0.38 0.12 145 / 0.08)' }}
              aria-hidden="true"
            />
            <div className="relative rounded-2xl overflow-hidden shadow-nature aspect-[4/3]">
              <img
                src="https://placehold.co/800x600?text=Interior+del+vivero+con+plantas+ornamentales+coloridas+en+exhibicion+luz+natural"
                alt="Interior del Vivero Garden Center Marysia con plantas ornamentales bien exhibidas bajo luz natural"
                className="w-full h-full object-cover"
                loading="lazy"
              />
              {/* Badge encima de la imagen */}
              <div className="absolute bottom-4 left-4 right-4">
                <div
                  className="backdrop-blur-sm text-white rounded-xl px-4 py-3 flex items-center gap-3"
                  style={{ background: 'oklch(0.25 0.07 142 / 0.9)' }}
                >
                  <div className="flex -space-x-2" aria-hidden="true">
                    {['M', 'J', 'A', 'C'].map((letter, i) => (
                      <div
                        key={i}
                        className="w-7 h-7 rounded-full border-2 flex items-center justify-center text-[10px] font-bold text-white"
                        style={{
                          background: 'oklch(0.38 0.12 145)',
                          borderColor: 'oklch(0.25 0.07 142)',
                        }}
                      >
                        {letter}
                      </div>
                    ))}
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-white leading-none">+200 clientes</p>
                    <p className="text-[10px] text-white/60 mt-0.5 leading-none">confían en nosotros</p>
                  </div>
                  <div className="ml-auto text-right">
                    <p className="font-bold text-sm leading-none" style={{ color: 'var(--gold)' }}>4.5 ★</p>
                    <p className="text-[10px] text-white/60 mt-0.5 leading-none">en Google</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ── Texto ── */}
          <div>
            <span
              className="inline-block font-semibold text-sm uppercase tracking-widest mb-3"
              style={{ color: 'var(--accent)' }}
            >
              {ABOUT_DATA.eyebrow}
            </span>
            <h2
              id="about-heading"
              className="font-serif text-3xl sm:text-4xl font-bold text-foreground leading-tight text-balance mb-6"
            >
              {ABOUT_DATA.headline}
            </h2>

            <div className="space-y-4 mb-8">
              {ABOUT_DATA.body.map((paragraph, i) => (
                <p key={i} className="text-muted-foreground leading-relaxed text-base">
                  {paragraph}
                </p>
              ))}
            </div>

            {/* Trust points */}
            <ul className="grid sm:grid-cols-2 gap-4 list-none" role="list">
              {TRUST_POINTS.map((point, i) => {
                const Icon = TRUST_ICONS[i]
                return (
                  <li
                    key={i}
                    className="flex items-start gap-3 p-4 rounded-xl border border-border transition-colors duration-200 hover:border-[var(--primary)]/30"
                    style={{ background: 'var(--section-cream)' }}
                  >
                    <span
                      className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                      style={{
                        background: 'var(--primary)',
                        color: 'var(--primary-foreground)',
                      }}
                      aria-hidden="true"
                    >
                      <Icon />
                    </span>
                    <div>
                      <p className="font-semibold text-foreground text-sm leading-tight mb-1">
                        {point.title}
                      </p>
                      <p className="text-muted-foreground text-xs leading-relaxed">
                        {point.desc}
                      </p>
                    </div>
                  </li>
                )
              })}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
