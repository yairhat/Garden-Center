'use client'

/**
 * PLANTAS ESPECIALES — Vivero Garden Center Marysia
 * "Si no la tenemos, la conseguimos."
 * PARA EDITAR: Cambia SPECIAL_DATA, EXAMPLES y FEATURES abajo.
 */

/* ====================================================
   DATOS EDITABLES
   ==================================================== */
const SPECIAL_DATA = {
  eyebrow: 'Pedidos especiales',
  headline: 'Si no la tenemos,\nla conseguimos.',
  body: 'Sabemos que cada espacio es único y que a veces buscas esa planta especial que no encuentras en cualquier lado. Dinos cuál es y nos encargamos de conseguirla para ti.',
  whatsappMsg: 'Hola! Estoy buscando una planta especial y me dijeron que ustedes pueden conseguirla. ¿Me pueden ayudar?',
  whatsappNum: '5959544223',
}

const EXAMPLES = [
  'Plantas exóticas',
  'Árboles específicos',
  'Suculentas raras',
  'Plantas medicinales',
  'Bonsáis',
  'Flores de temporada',
]

const FEATURES = [
  {
    title: 'Cuéntanos qué buscas',
    desc: 'Mándanos una foto, el nombre o una descripción. Cualquier pista nos ayuda.',
  },
  {
    title: 'Cotizamos sin costo',
    desc: 'Te damos precio y tiempo estimado sin ningún compromiso de tu parte.',
  },
  {
    title: 'La tenemos lista para ti',
    desc: 'Cuando llegue, te avisamos y la puedes pasar a recoger o apartar.',
  },
]

export default function SpecialPlants() {
  const waUrl = `https://wa.me/52${SPECIAL_DATA.whatsappNum}?text=${encodeURIComponent(SPECIAL_DATA.whatsappMsg)}`

  return (
    <section
      id="plantas-especiales"
      className="relative py-20 sm:py-28 overflow-hidden"
      style={{ background: 'var(--section-green)' }}
      aria-labelledby="special-heading"
    >
      {/* Patron de fondo */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.06) 1px, transparent 1px)',
          backgroundSize: '28px 28px',
        }}
        aria-hidden="true"
      />

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* Columna izquierda: texto */}
          <div>
            <span className="inline-flex items-center gap-2 font-semibold text-sm uppercase tracking-widest mb-4" style={{ color: 'var(--gold)' }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
              </svg>
              {SPECIAL_DATA.eyebrow}
            </span>

            <h2
              id="special-heading"
              className="font-serif font-bold text-white text-balance leading-tight mb-5 whitespace-pre-line"
              style={{ fontSize: 'clamp(2rem, 5vw, 3rem)' }}
            >
              {SPECIAL_DATA.headline}
            </h2>

            <p className="text-lg leading-relaxed text-pretty mb-8" style={{ color: 'rgba(255,255,255,0.7)' }}>
              {SPECIAL_DATA.body}
            </p>

            {/* Pasos */}
            <div className="space-y-5 mb-10">
              {FEATURES.map((f, i) => (
                <div key={i} className="flex items-start gap-4">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 text-xs font-bold"
                    style={{ background: 'var(--gold)', color: 'var(--gold-foreground)' }}
                  >
                    {i + 1}
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm">{f.title}</p>
                    <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.55)' }}>{f.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* CTA */}
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 px-8 py-4 text-white font-semibold rounded-full text-base transition-all duration-300 hover:scale-105"
              style={{ background: '#25D366', boxShadow: '0 8px 24px -4px rgba(37,211,102,0.4)' }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.63"/>
              </svg>
              Pedir una planta especial
            </a>
          </div>

          {/* Columna derecha: tarjetas */}
          <div className="flex flex-col gap-4">

            {/* Tarjeta de tiempo de respuesta */}
            <div
              className="rounded-3xl p-6 sm:p-8"
              style={{ background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.12)' }}
            >
              <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'oklch(0.72 0.12 78 / 0.2)' }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--gold)" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M12 6v6l4 2"/>
                  </svg>
                </div>
                <div>
                  <p className="text-white font-semibold text-sm">Tiempo de respuesta</p>
                  <p className="text-xs" style={{ color: 'rgba(255,255,255,0.45)' }}>Generalmente 24 – 72 horas</p>
                </div>
              </div>

              <p className="text-sm leading-relaxed mb-6" style={{ color: 'rgba(255,255,255,0.65)' }}>
                Tenemos proveedores y contactos en toda la zona para conseguir casi cualquier especie. Si existe, la encontramos.
              </p>

              {/* Tags de ejemplos */}
              <p className="text-xs uppercase tracking-wider mb-3" style={{ color: 'rgba(255,255,255,0.35)' }}>
                Ejemplos de pedidos especiales
              </p>
              <div className="flex flex-wrap gap-2">
                {EXAMPLES.map((ex) => (
                  <span
                    key={ex}
                    className="px-3 py-1.5 rounded-full text-xs font-medium transition-colors duration-200"
                    style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.14)', color: 'rgba(255,255,255,0.75)' }}
                  >
                    {ex}
                  </span>
                ))}
              </div>
            </div>

            {/* Tarjeta promesa */}
            <div
              className="rounded-2xl p-5 flex items-start gap-4"
              style={{ background: 'oklch(0.72 0.12 78 / 0.12)', border: '1px solid oklch(0.72 0.12 78 / 0.28)' }}
            >
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ background: 'oklch(0.72 0.12 78 / 0.2)' }}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--gold)" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                  <path d="m9 12 2 2 4-4"/>
                </svg>
              </div>
              <div>
                <p className="font-semibold text-sm mb-1" style={{ color: 'var(--gold)' }}>Nuestra promesa</p>
                <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.58)' }}>
                  Si no podemos conseguirla, te lo decimos con honestidad. Cero compromisos, cero cobros adelantados.
                </p>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  )
}
