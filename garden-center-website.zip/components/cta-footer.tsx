'use client'

/**
 * CTA FINAL + FOOTER + BOTÓN WHATSAPP FLOTANTE
 * ──────────────────────────────────────────────
 * • Sección CTA con mensaje urgente y botones de conversión
 * • Footer con links, datos del negocio y créditos
 * • Botón flotante de WhatsApp (siempre visible)
 * • Botón "volver arriba" al hacer scroll
 *
 * PARA EDITAR: Cambia BUSINESS_INFO y CTA_DATA abajo.
 */

import { useState, useEffect } from 'react'

/* ====================================================
   DATOS EDITABLES
   ==================================================== */
const BUSINESS_INFO = {
  name: 'Garden Center Marysia',
  address: 'Carr al Molino de Flores 8, Xocotlan, Texcoco, Estado de México',
  phone: '5959544223',
  phoneDisplay: '595 954 4223',
  whatsapp: '5959544223',
}

const CTA_DATA = {
  eyebrow: 'No esperes más',
  headline: 'Tu jardín ideal empieza con una visita',
  body: 'Ven a conocernos hoy. Tenemos cientos de plantas esperándote y un equipo dispuesto a ayudarte a elegir la perfecta para tu espacio. Sin compromiso, solo amor por las plantas.',
  primaryCTA: 'Cotizar por WhatsApp',
  secondaryCTA: 'Cómo llegar',
  whatsappMsg: 'Hola! Me gustaría visitar el vivero hoy. ¿Qué días están abiertos?',
}

const FOOTER_LINKS = [
  { label: 'Inicio', href: '#inicio' },
  { label: 'Nosotros', href: '#nosotros' },
  { label: 'Productos', href: '#productos' },
  { label: 'Galería', href: '#galeria' },
  { label: 'Contacto', href: '#contacto' },
]

function WhatsAppButton() {
  const [visible, setVisible] = useState(false)
  const whatsappUrl = `https://wa.me/52${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(CTA_DATA.whatsappMsg)}`

  useEffect(() => {
    // Mostrar el botón después de 1.5s para no distraer el primer impacto
    const t = setTimeout(() => setVisible(true), 1500)
    return () => clearTimeout(t)
  }, [])

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Enviar mensaje por WhatsApp"
      className={`fixed bottom-6 right-5 z-50 group flex items-center gap-2 transition-all duration-500 ${
        visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8 pointer-events-none'
      }`}
    >
      {/* Tooltip label */}
      <span
        className="bg-[var(--hero-bg)] text-white text-xs font-semibold px-3 py-1.5 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-200 whitespace-nowrap -translate-x-2 group-hover:translate-x-0"
        aria-hidden="true"
      >
        Escríbenos
      </span>

      {/* Botón circular */}
      <div className="w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-xl hover:bg-[#20B858] transition-colors duration-200 wa-pulse hover:[animation:none]">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="white" aria-hidden="true">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.63"/>
        </svg>
      </div>
    </a>
  )
}

function BackToTop() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const handleScroll = () => setVisible(window.scrollY > 600)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      aria-label="Volver arriba"
      className={`fixed bottom-6 left-5 z-50 w-11 h-11 bg-[var(--primary)] text-[var(--primary-foreground)] rounded-full flex items-center justify-center shadow-lg hover:bg-[var(--primary)]/85 transition-all duration-300 ${
        visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8 pointer-events-none'
      }`}
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true">
        <path d="M18 15l-6-6-6 6"/>
      </svg>
    </button>
  )
}

export default function CtaFooter() {
  const whatsappUrl = `https://wa.me/52${BUSINESS_INFO.whatsapp}?text=${encodeURIComponent(CTA_DATA.whatsappMsg)}`

  return (
    <>
      {/* ════════════════════════════
          SECCIÓN CTA FINAL
          ════════════════════════════ */}
      <section
        className="relative py-20 sm:py-28 bg-[var(--primary)] overflow-hidden"
        aria-labelledby="cta-heading"
      >
        {/* Patrón de fondo */}
        <div
          className="absolute inset-0 opacity-[0.06]"
          style={{
            backgroundImage: `radial-gradient(circle, white 1.5px, transparent 1.5px)`,
            backgroundSize: '32px 32px',
          }}
          aria-hidden="true"
        />

        {/* Formas decorativas */}
        <div
          className="absolute -top-24 -right-24 w-72 h-72 rounded-full bg-[var(--gold)]/15 blur-3xl"
          aria-hidden="true"
        />
        <div
          className="absolute -bottom-24 -left-24 w-72 h-72 rounded-full bg-white/10 blur-3xl"
          aria-hidden="true"
        />

        <div className="relative z-10 max-w-3xl mx-auto px-4 sm:px-6 text-center">
          <span className="inline-block text-[var(--gold)] font-semibold text-sm uppercase tracking-widest mb-4">
            {CTA_DATA.eyebrow}
          </span>
          <h2
            id="cta-heading"
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-white text-balance mb-5 leading-tight"
          >
            {CTA_DATA.headline}
          </h2>
          <p className="text-white/75 text-lg leading-relaxed mb-10 text-pretty max-w-xl mx-auto">
            {CTA_DATA.body}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {/* WhatsApp */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 px-8 py-4 bg-[#25D366] text-white font-semibold rounded-full shadow-xl hover:bg-[#20B858] transition-all duration-300 hover:scale-105 text-base"
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.63"/>
              </svg>
              {CTA_DATA.primaryCTA}
            </a>

            {/* Cómo llegar */}
            <a
              href={`https://www.google.com.mx/maps/place/Vivero+Garden+Center+Marysia/`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 px-8 py-4 bg-white/10 text-white font-semibold rounded-full border border-white/30 hover:bg-white/20 transition-all duration-300 hover:scale-105 text-base backdrop-blur-sm"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
              </svg>
              {CTA_DATA.secondaryCTA}
            </a>
          </div>

          {/* Teléfono visible */}
          <p className="mt-8 text-white/50 text-sm">
            O llámanos directamente:{'  '}
            <a
              href={`tel:${BUSINESS_INFO.phone}`}
              className="text-white font-semibold hover:text-[var(--gold)] transition-colors duration-200"
            >
              {BUSINESS_INFO.phoneDisplay}
            </a>
          </p>
        </div>
      </section>

      {/* ════════════════════════════
          FOOTER
          ════════════════════════════ */}
      <footer className="bg-[var(--hero-bg)] py-12 sm:py-16" role="contentinfo">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-10 pb-10 border-b border-white/10">

            {/* Columna 1 — Marca */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <span className="relative w-10 h-10 flex-shrink-0" aria-hidden="true">
                  <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                    <path d="M20 3 C20 3 34 8 34 20 C34 30 27 37 20 37 C13 37 6 30 6 20 C6 8 20 3 20 3Z" fill="var(--gold)" opacity="0.18"/>
                    <path d="M20 6 C20 6 32 11 32 20 C32 28.5 26.5 35 20 35 C13.5 35 8 28.5 8 20 C8 11 20 6 20 6Z" fill="none" stroke="var(--gold)" strokeWidth="1.2"/>
                    <line x1="20" y1="10" x2="20" y2="33" stroke="var(--gold)" strokeWidth="0.8" strokeDasharray="2 2" opacity="0.6"/>
                    <line x1="20" y1="16" x2="13" y2="22" stroke="var(--gold)" strokeWidth="0.6" opacity="0.5"/>
                    <line x1="20" y1="16" x2="27" y2="22" stroke="var(--gold)" strokeWidth="0.6" opacity="0.5"/>
                  </svg>
                </span>
                <div>
                  <span className="block font-serif font-bold text-white text-[15px] leading-none tracking-tight">Garden Center</span>
                  <div className="flex items-center gap-1.5 mt-[3px]">
                    <span className="block text-[var(--gold)] text-[11px] font-semibold tracking-[0.18em] uppercase leading-none">Marysia</span>
                    <span className="w-1 h-1 rounded-full bg-[var(--gold)]/50 inline-block"/>
                    <span className="text-white/35 text-[9px] tracking-wider uppercase leading-none">Vivero</span>
                  </div>
                </div>
              </div>
              <p className="text-white/50 text-sm leading-relaxed">
                Tu vivero de confianza en Texcoco, Estado de México. Plantas, árboles y asesoría para hacer crecer tus espacios verdes.
              </p>
            </div>

            {/* Columna 2 — Navegación */}
            <div>
              <h3 className="text-white font-semibold text-sm uppercase tracking-widest mb-4">Navegación</h3>
              <ul className="space-y-2 list-none" role="list">
                {FOOTER_LINKS.map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      onClick={(e) => {
                        e.preventDefault()
                        document.querySelector(link.href)?.scrollIntoView({ behavior: 'smooth' })
                      }}
                      className="text-white/50 text-sm hover:text-[var(--gold)] transition-colors duration-200"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Columna 3 — Contacto rápido */}
            <div>
              <h3 className="text-white font-semibold text-sm uppercase tracking-widest mb-4">Contacto</h3>
              <address className="not-italic space-y-3">
                <p className="text-white/50 text-sm leading-relaxed">{BUSINESS_INFO.address}</p>
                <a
                  href={`tel:${BUSINESS_INFO.phone}`}
                  className="block text-white/50 text-sm hover:text-[var(--gold)] transition-colors duration-200"
                >
                  {BUSINESS_INFO.phoneDisplay}
                </a>
                <a
                  href={`https://wa.me/52${BUSINESS_INFO.whatsapp}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-[#25D366] text-sm font-medium hover:text-[#20B858] transition-colors duration-200"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.63"/>
                  </svg>
                  WhatsApp
                </a>
              </address>
            </div>
          </div>

          {/* Bottom bar */}
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-white/30 text-xs text-center sm:text-left">
              &copy; {new Date().getFullYear()} Vivero Garden Center Marysia. Todos los derechos reservados.
            </p>
            <p className="text-white/25 text-xs">
              Texcoco, Estado de México
            </p>
          </div>
        </div>
      </footer>

      {/* ── Botones flotantes ── */}
      <WhatsAppButton />
      <BackToTop />
    </>
  )
}
