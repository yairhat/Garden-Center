/**
 * CONTACTO Y UBICACIÓN — Vivero Garden Center Marysia
 * ──────────────────────────────────────────────────────
 * PARA EDITAR: Cambia CONTACT_DATA y SCHEDULE abajo.
 * Para el mapa real: ve a Google Maps → busca el vivero →
 * Compartir → Insertar mapa → copia el src del iframe aquí.
 */

/* ====================================================
   DATOS EDITABLES
   ==================================================== */
const CONTACT_DATA = {
  address: 'Carr al Molino de Flores 8, Xocotlan, Texcoco, Estado de México',
  phone: '5959544223',
  phoneDisplay: '595 954 4223',
  whatsapp: '5959544223',
  whatsappMsg: 'Hola, quisiera información sobre sus productos y horarios de atención.',
  googleMapsUrl: 'https://www.google.com.mx/maps/place/Vivero+Garden+Center+Marysia/',
  // Para obtener el embed correcto:
  // 1. Abre Google Maps y busca el vivero
  // 2. Click en "Compartir" → "Insertar un mapa"
  // 3. Copia el src del iframe y pégalo aquí
  mapEmbedSrc:
    'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d939.1!2d-98.8835!3d19.5217!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d1f4b97f3e0001%3A0x5ccf5a7b4a45890f!2sVivero%20Garden%20Center%20Marysia!5e0!3m2!1ses-419!2smx!4v1713484800000!5m2!1ses-419!2smx',
}

// Horarios de atención — edita según los horarios reales del vivero
const SCHEDULE = [
  { days: 'Lunes – Viernes', hours: '8:00 am – 6:00 pm' },
  { days: 'Sábado', hours: '8:00 am – 5:00 pm' },
  { days: 'Domingo', hours: '9:00 am – 3:00 pm' },
]

export default function Contact() {
  const whatsappUrl = `https://wa.me/52${CONTACT_DATA.whatsapp}?text=${encodeURIComponent(
    CONTACT_DATA.whatsappMsg
  )}`

  return (
    <section
      id="contacto"
      className="py-20 sm:py-28 bg-background"
      aria-labelledby="contact-heading"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-14">
          <span
            className="inline-block font-semibold text-sm uppercase tracking-widest mb-3"
            style={{ color: 'var(--accent)' }}
          >
            Encuéntranos
          </span>
          <h2
            id="contact-heading"
            className="font-serif text-3xl sm:text-4xl font-bold text-foreground text-balance mb-4"
          >
            Visítanos en Texcoco
          </h2>
          <p className="text-muted-foreground text-base max-w-lg mx-auto leading-relaxed">
            Estamos ubicados cerca del Molino de Flores. Ven a elegir tus plantas en persona — la experiencia vale la pena.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-8 items-start">

          {/* ── Panel de información (2/5) ── */}
          <div className="lg:col-span-2 flex flex-col gap-6">

            {/* Info de contacto */}
            <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
              <h3 className="font-semibold text-foreground text-base mb-5">Información de contacto</h3>
              <ul className="space-y-5 list-none" role="list">

                {/* Dirección */}
                <li className="flex items-start gap-3">
                  <span
                    className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                      <circle cx="12" cy="10" r="3" />
                    </svg>
                  </span>
                  <div>
                    <p className="text-muted-foreground text-xs font-medium mb-0.5">Dirección</p>
                    <a
                      href={CONTACT_DATA.googleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-foreground text-sm font-medium leading-snug hover:text-[var(--primary)] transition-colors duration-200"
                    >
                      {CONTACT_DATA.address}
                    </a>
                  </div>
                </li>

                {/* Teléfono */}
                <li className="flex items-start gap-3">
                  <span
                    className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.34 2 2 0 0 1 3.6 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.6a16 16 0 0 0 6.29 6.29l1.06-.98a2 2 0 0 1 2.1-.45c.908.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" />
                    </svg>
                  </span>
                  <div>
                    <p className="text-muted-foreground text-xs font-medium mb-0.5">Teléfono</p>
                    <a
                      href={`tel:${CONTACT_DATA.phone}`}
                      className="text-foreground text-sm font-medium hover:text-[var(--primary)] transition-colors duration-200"
                    >
                      {CONTACT_DATA.phoneDisplay}
                    </a>
                  </div>
                </li>

                {/* WhatsApp */}
                <li className="flex items-start gap-3">
                  <span
                    className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.63" />
                    </svg>
                  </span>
                  <div>
                    <p className="text-muted-foreground text-xs font-medium mb-0.5">WhatsApp</p>
                    <a
                      href={whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-foreground text-sm font-medium hover:text-[var(--primary)] transition-colors duration-200"
                    >
                      {CONTACT_DATA.phoneDisplay}
                    </a>
                  </div>
                </li>
              </ul>
            </div>

            {/* Horarios */}
            <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-2 mb-5">
                <h3 className="font-semibold text-foreground text-base">Horarios de atención</h3>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full">
                  Abierto hoy
                </span>
              </div>
              <ul className="space-y-3 list-none" role="list">
                {SCHEDULE.map((item, i) => (
                  <li
                    key={i}
                    className="flex items-center justify-between py-2 border-b border-border last:border-0"
                  >
                    <span className="text-muted-foreground text-sm">{item.days}</span>
                    <span className="text-foreground text-sm font-semibold">{item.hours}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* CTA directo */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 w-full py-4 text-white font-semibold rounded-2xl transition-all duration-200 hover:scale-[1.02] shadow-md text-sm"
              style={{ background: '#25D366' }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.63" />
              </svg>
              Escribir por WhatsApp
            </a>
          </div>

          {/* ── Mapa embebido (3/5) ── */}
          <div className="lg:col-span-3">
            <div className="rounded-2xl overflow-hidden border border-border shadow-sm" style={{ minHeight: 460 }}>
              <iframe
                title="Mapa de ubicación del Vivero Garden Center Marysia en Texcoco"
                src={CONTACT_DATA.mapEmbedSrc}
                width="100%"
                height="460"
                style={{ border: 0, display: 'block' }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            <a
              href={CONTACT_DATA.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-3 flex items-center justify-center gap-2 text-sm font-medium hover:underline transition-colors duration-200"
              style={{ color: 'var(--primary)' }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14 21 3" />
              </svg>
              Ver en Google Maps
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
