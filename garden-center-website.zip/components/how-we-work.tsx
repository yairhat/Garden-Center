'use client'

/**
 * CÓMO TRABAJAMOS — Vivero Garden Center Marysia
 * PARA EDITAR: Cambia los textos en STEPS y WHATSAPP_NUM abajo.
 */

/* ====================================================
   DATOS EDITABLES
   ==================================================== */
const STEPS = [
  {
    number: '01',
    title: 'Nos contactas',
    description:
      'Escríbenos por WhatsApp o llámanos. Cuéntanos qué tipo de planta buscas, para qué espacio es y cualquier detalle que nos ayude a orientarte mejor.',
    cta: 'Escribir ahora',
    ctaType: 'whatsapp' as const,
  },
  {
    number: '02',
    title: 'Te mandamos fotos',
    description:
      'Te enviamos fotografías reales de las plantas disponibles o de opciones similares para que elijas con total confianza desde donde estés.',
    cta: null,
    ctaType: null,
  },
  {
    number: '03',
    title: 'Apartas o nos visitas',
    description:
      'Aparta tu planta con total confianza o visítanos directamente. Te esperamos con atención personalizada y muchas plantas para elegir.',
    cta: 'Cómo llegar',
    ctaType: 'maps' as const,
  },
]

const WHATSAPP_NUM = '5959544223'
const MAPS_URL = 'https://www.google.com.mx/maps/place/Vivero+Garden+Center+Marysia/'

/* Iconos como componentes independientes (no como JSX en objetos) */
function IconPhone() {
  return (
    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.53 2 2 0 0 1 3.6 1.36h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.96a16 16 0 0 0 6.13 6.13l.95-.95a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
    </svg>
  )
}

function IconPhoto() {
  return (
    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="3" y="3" width="18" height="18" rx="2"/>
      <circle cx="8.5" cy="8.5" r="1.5"/>
      <path d="m21 15-5-5L5 21"/>
    </svg>
  )
}

function IconPin() {
  return (
    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0Z"/>
      <circle cx="12" cy="10" r="3"/>
    </svg>
  )
}

const STEP_ICONS = [IconPhone, IconPhoto, IconPin]

export default function HowWeWork() {
  const waUrl = `https://wa.me/52${WHATSAPP_NUM}?text=${encodeURIComponent('Hola, me gustaría ver fotos de plantas disponibles.')}`

  return (
    <section
      id="como-trabajamos"
      className="py-20 sm:py-28 bg-[var(--section-cream)]"
      aria-labelledby="how-heading"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6">

        {/* Encabezado */}
        <div className="text-center mb-16">
          <span className="inline-block text-[var(--accent)] font-semibold text-sm uppercase tracking-widest mb-3">
            Simple y sin complicaciones
          </span>
          <h2
            id="how-heading"
            className="font-serif text-3xl sm:text-4xl font-bold text-foreground text-balance mb-4"
          >
            ¿Cómo trabajamos?
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto leading-relaxed text-pretty">
            Encontrar la planta perfecta nunca fue tan fácil. Te acompañamos desde el primer mensaje hasta que llegue a tu hogar.
          </p>
        </div>

        {/* Pasos */}
        <div className="relative">
          {/* Línea conectora — solo desktop */}
          <div
            className="hidden lg:block absolute top-[52px] left-[calc(16.666%+3rem)] right-[calc(16.666%+3rem)] h-px"
            style={{ background: 'linear-gradient(to right, transparent, var(--border), var(--border), transparent)' }}
            aria-hidden="true"
          />

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-10 lg:gap-12">
            {STEPS.map((step, i) => {
              const Icon = STEP_ICONS[i]
              return (
                <div
                  key={step.number}
                  className="relative flex flex-col items-center text-center group"
                >
                  {/* Número de fondo decorativo */}
                  <span
                    className="absolute -top-4 left-1/2 -translate-x-1/2 font-serif font-bold leading-none select-none pointer-events-none"
                    style={{ fontSize: '7rem', color: 'oklch(0.38 0.12 145 / 0.05)' }}
                    aria-hidden="true"
                  >
                    {step.number}
                  </span>

                  {/* Icono circular */}
                  <div className="relative z-10 mb-6">
                    <div
                      className="w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 group-hover:scale-105"
                      style={{
                        background: 'var(--primary)',
                        color: 'var(--primary-foreground)',
                        boxShadow: '0 8px 28px -4px oklch(0.38 0.12 145 / 0.3)',
                      }}
                    >
                      <Icon />
                    </div>
                    {/* Badge número */}
                    <span
                      className="absolute -top-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shadow"
                      style={{ background: 'var(--gold)', color: 'var(--gold-foreground)' }}
                    >
                      {i + 1}
                    </span>
                  </div>

                  {/* Texto */}
                  <h3 className="font-serif text-xl font-bold text-foreground mb-3">
                    {step.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed text-pretty flex-1 max-w-xs mx-auto">
                    {step.description}
                  </p>

                  {/* CTA del paso */}
                  {step.cta && (
                    <a
                      href={step.ctaType === 'whatsapp' ? waUrl : MAPS_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-5 inline-flex items-center gap-2 text-sm font-semibold transition-colors duration-200 group/link"
                      style={{ color: 'var(--accent)' }}
                    >
                      {step.cta}
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true" className="group-hover/link:translate-x-1 transition-transform duration-200">
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                      </svg>
                    </a>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* Banner inferior */}
        <div
          className="mt-16 rounded-2xl px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-4"
          style={{ background: 'oklch(0.38 0.12 145 / 0.08)', border: '1px solid oklch(0.38 0.12 145 / 0.15)' }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ background: 'oklch(0.38 0.12 145 / 0.15)' }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
                <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/>
                <path d="m9 12 2 2 4-4"/>
              </svg>
            </div>
            <p className="text-foreground text-sm font-medium">
              Sin compromiso. Sin costos ocultos. Solo amor por las plantas.
            </p>
          </div>
          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 px-6 py-2.5 text-sm font-semibold rounded-full transition-colors duration-200"
            style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
          >
            Empezar ahora
          </a>
        </div>
      </div>
    </section>
  )
}
